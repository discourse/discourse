--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE categories (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    color character varying(6) DEFAULT 'AB9364'::character varying NOT NULL,
    topic_id integer,
    top1_topic_id integer,
    top2_topic_id integer,
    top1_user_id integer,
    top2_user_id integer,
    topic_count integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    user_id integer NOT NULL,
    topics_year integer,
    topics_month integer,
    topics_week integer,
    slug character varying(255) NOT NULL
);


--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE categories_id_seq OWNED BY categories.id;


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('categories_id_seq', 1, false);


--
-- Name: category_featured_topics; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE category_featured_topics (
    category_id integer NOT NULL,
    topic_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: category_featured_users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE category_featured_users (
    id integer NOT NULL,
    category_id integer,
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: category_featured_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE category_featured_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: category_featured_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE category_featured_users_id_seq OWNED BY category_featured_users.id;


--
-- Name: category_featured_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('category_featured_users_id_seq', 1, false);


--
-- Name: draft_sequences; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE draft_sequences (
    id integer NOT NULL,
    user_id integer NOT NULL,
    draft_key character varying(255) NOT NULL,
    sequence integer NOT NULL
);


--
-- Name: draft_sequences_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE draft_sequences_id_seq
    START WITH 13
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: draft_sequences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE draft_sequences_id_seq OWNED BY draft_sequences.id;


--
-- Name: draft_sequences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('draft_sequences_id_seq', 13, false);


--
-- Name: drafts; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE drafts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    draft_key character varying(255) NOT NULL,
    data text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    sequence integer DEFAULT 0 NOT NULL
);


--
-- Name: drafts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE drafts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: drafts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE drafts_id_seq OWNED BY drafts.id;


--
-- Name: drafts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('drafts_id_seq', 1, false);


--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE email_logs (
    id integer NOT NULL,
    to_address character varying(255) NOT NULL,
    email_type character varying(255) NOT NULL,
    user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: email_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE email_logs_id_seq
    START WITH 3
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE email_logs_id_seq OWNED BY email_logs.id;


--
-- Name: email_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('email_logs_id_seq', 3, false);


--
-- Name: email_tokens; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE email_tokens (
    id integer NOT NULL,
    user_id integer NOT NULL,
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    confirmed boolean DEFAULT false NOT NULL,
    expired boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: email_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE email_tokens_id_seq
    START WITH 3
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: email_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE email_tokens_id_seq OWNED BY email_tokens.id;


--
-- Name: email_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('email_tokens_id_seq', 3, false);


--
-- Name: facebook_user_infos; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE facebook_user_infos (
    id integer NOT NULL,
    user_id integer NOT NULL,
    facebook_user_id integer NOT NULL,
    username character varying(255) NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    email character varying(255),
    gender character varying(255),
    name character varying(255),
    link character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: facebook_user_infos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE facebook_user_infos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: facebook_user_infos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE facebook_user_infos_id_seq OWNED BY facebook_user_infos.id;


--
-- Name: facebook_user_infos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('facebook_user_infos_id_seq', 1, false);


--
-- Name: incoming_links; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE incoming_links (
    id integer NOT NULL,
    url character varying(1000) NOT NULL,
    referer character varying(1000) NOT NULL,
    domain character varying(100) NOT NULL,
    topic_id integer,
    post_number integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: incoming_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE incoming_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: incoming_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE incoming_links_id_seq OWNED BY incoming_links.id;


--
-- Name: incoming_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('incoming_links_id_seq', 1, false);


--
-- Name: invites; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE invites (
    id integer NOT NULL,
    invite_key character varying(32) NOT NULL,
    email character varying(255) NOT NULL,
    invited_by_id integer NOT NULL,
    user_id integer,
    redeemed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    deleted_at timestamp without time zone
);


--
-- Name: invites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE invites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE invites_id_seq OWNED BY invites.id;


--
-- Name: invites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('invites_id_seq', 1, false);


--
-- Name: message_bus; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE message_bus (
    id integer NOT NULL,
    name character varying(255),
    context character varying(255),
    data text,
    created_at timestamp without time zone
);


--
-- Name: message_bus_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE message_bus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: message_bus_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE message_bus_id_seq OWNED BY message_bus.id;


--
-- Name: message_bus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('message_bus_id_seq', 12501, true);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE notifications (
    id integer NOT NULL,
    notification_type integer NOT NULL,
    user_id integer NOT NULL,
    data character varying(255) NOT NULL,
    read boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    topic_id integer,
    post_number integer,
    post_action_id integer
);


--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE notifications_id_seq OWNED BY notifications.id;


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('notifications_id_seq', 1, false);


--
-- Name: onebox_renders; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE onebox_renders (
    id integer NOT NULL,
    url character varying(255) NOT NULL,
    cooked text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    preview text
);


--
-- Name: onebox_renders_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE onebox_renders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: onebox_renders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE onebox_renders_id_seq OWNED BY onebox_renders.id;


--
-- Name: onebox_renders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('onebox_renders_id_seq', 1, false);


--
-- Name: post_action_types; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_action_types (
    name_key character varying(50) NOT NULL,
    is_flag boolean DEFAULT false NOT NULL,
    icon character varying(20),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    id integer NOT NULL
);


--
-- Name: post_action_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE post_action_types_id_seq
    START WITH 6
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: post_action_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE post_action_types_id_seq OWNED BY post_action_types.id;


--
-- Name: post_action_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('post_action_types_id_seq', 6, false);


--
-- Name: post_actions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_actions (
    id integer NOT NULL,
    post_id integer NOT NULL,
    user_id integer NOT NULL,
    post_action_type_id integer NOT NULL,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: post_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE post_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: post_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE post_actions_id_seq OWNED BY post_actions.id;


--
-- Name: post_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('post_actions_id_seq', 1, false);


--
-- Name: post_onebox_renders; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_onebox_renders (
    post_id integer NOT NULL,
    onebox_render_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: post_replies; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_replies (
    post_id integer,
    reply_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: post_timings; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE post_timings (
    topic_id integer NOT NULL,
    post_number integer NOT NULL,
    user_id integer NOT NULL,
    msecs integer NOT NULL
);


--
-- Name: posts; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE posts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    topic_id integer NOT NULL,
    post_number integer NOT NULL,
    raw text NOT NULL,
    cooked text NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    reply_to_post_number integer,
    cached_version integer DEFAULT 1 NOT NULL,
    reply_count integer DEFAULT 0 NOT NULL,
    quote_count integer DEFAULT 0 NOT NULL,
    reply_below_post_number integer,
    deleted_at timestamp without time zone,
    off_topic_count integer DEFAULT 0 NOT NULL,
    offensive_count integer DEFAULT 0 NOT NULL,
    like_count integer DEFAULT 0 NOT NULL,
    incoming_link_count integer DEFAULT 0 NOT NULL,
    bookmark_count integer DEFAULT 0 NOT NULL,
    avg_time integer,
    score double precision,
    reads integer DEFAULT 0 NOT NULL,
    post_type integer DEFAULT 1 NOT NULL,
    vote_count integer DEFAULT 0 NOT NULL,
    sort_order integer,
    last_editor_id integer
);


--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE posts_id_seq
    START WITH 10
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE posts_id_seq OWNED BY posts.id;


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('posts_id_seq', 10, false);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE schema_migrations (
    version character varying(255) NOT NULL
);


--
-- Name: site_customizations; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE site_customizations (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    stylesheet text,
    header text,
    "position" integer NOT NULL,
    user_id integer NOT NULL,
    enabled boolean NOT NULL,
    key character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    override_default_style boolean DEFAULT false NOT NULL,
    stylesheet_baked text DEFAULT ''::text NOT NULL
);


--
-- Name: site_customizations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE site_customizations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_customizations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE site_customizations_id_seq OWNED BY site_customizations.id;


--
-- Name: site_customizations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('site_customizations_id_seq', 1, false);


--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE site_settings (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    data_type integer NOT NULL,
    value text,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: site_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE site_settings_id_seq
    START WITH 3
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: site_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE site_settings_id_seq OWNED BY site_settings.id;


--
-- Name: site_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('site_settings_id_seq', 3, false);


--
-- Name: topic_allowed_users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_allowed_users (
    id integer NOT NULL,
    user_id integer NOT NULL,
    topic_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: topic_allowed_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topic_allowed_users_id_seq
    START WITH 3
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: topic_allowed_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topic_allowed_users_id_seq OWNED BY topic_allowed_users.id;


--
-- Name: topic_allowed_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topic_allowed_users_id_seq', 3, false);


--
-- Name: topic_invites; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_invites (
    id integer NOT NULL,
    topic_id integer NOT NULL,
    invite_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: topic_invites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topic_invites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: topic_invites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topic_invites_id_seq OWNED BY topic_invites.id;


--
-- Name: topic_invites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topic_invites_id_seq', 1, false);


--
-- Name: topic_link_clicks; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_link_clicks (
    id integer NOT NULL,
    topic_link_id integer NOT NULL,
    user_id integer,
    ip bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: topic_link_clicks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topic_link_clicks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: topic_link_clicks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topic_link_clicks_id_seq OWNED BY topic_link_clicks.id;


--
-- Name: topic_link_clicks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topic_link_clicks_id_seq', 1, false);


--
-- Name: topic_links; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_links (
    id integer NOT NULL,
    topic_id integer NOT NULL,
    post_id integer,
    user_id integer NOT NULL,
    url character varying(500) NOT NULL,
    domain character varying(100) NOT NULL,
    internal boolean DEFAULT false NOT NULL,
    link_topic_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    reflection boolean DEFAULT false,
    clicks integer DEFAULT 0 NOT NULL,
    link_post_id integer
);


--
-- Name: topic_links_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topic_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: topic_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topic_links_id_seq OWNED BY topic_links.id;


--
-- Name: topic_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topic_links_id_seq', 1, false);


--
-- Name: topic_users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topic_users (
    user_id integer NOT NULL,
    topic_id integer NOT NULL,
    starred boolean DEFAULT false NOT NULL,
    posted boolean DEFAULT false NOT NULL,
    last_read_post_number integer,
    seen_post_count integer,
    starred_at timestamp without time zone,
    muted_at timestamp without time zone,
    last_visited_at timestamp without time zone,
    first_visited_at timestamp without time zone,
    notifications integer DEFAULT 2,
    notifications_changed_at timestamp without time zone,
    notifications_reason_id integer,
    CONSTRAINT test_starred_at CHECK (((starred = false) OR (starred_at IS NOT NULL)))
);


--
-- Name: topics; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE topics (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    last_posted_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    views integer DEFAULT 0 NOT NULL,
    posts_count integer DEFAULT 0 NOT NULL,
    user_id integer NOT NULL,
    last_post_user_id integer NOT NULL,
    reply_count integer DEFAULT 0 NOT NULL,
    featured_user1_id integer,
    featured_user2_id integer,
    featured_user3_id integer,
    avg_time integer,
    deleted_at timestamp without time zone,
    highest_post_number integer DEFAULT 0 NOT NULL,
    image_url character varying(255),
    off_topic_count integer DEFAULT 0 NOT NULL,
    offensive_count integer DEFAULT 0 NOT NULL,
    like_count integer DEFAULT 0 NOT NULL,
    incoming_link_count integer DEFAULT 0 NOT NULL,
    bookmark_count integer DEFAULT 0 NOT NULL,
    star_count integer DEFAULT 0 NOT NULL,
    category_id integer,
    visible boolean DEFAULT true NOT NULL,
    moderator_posts_count integer DEFAULT 0 NOT NULL,
    closed boolean DEFAULT false NOT NULL,
    pinned boolean DEFAULT false NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    bumped_at timestamp without time zone NOT NULL,
    sub_tag character varying(255),
    has_best_of boolean DEFAULT false NOT NULL,
    meta_data hstore,
    vote_count integer DEFAULT 0 NOT NULL,
    archetype character varying(255) DEFAULT 'regular'::character varying NOT NULL,
    featured_user4_id integer
);


--
-- Name: topics_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE topics_id_seq
    START WITH 10
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: topics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE topics_id_seq OWNED BY topics.id;


--
-- Name: topics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('topics_id_seq', 10, false);


--
-- Name: trust_levels; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE trust_levels (
    id integer NOT NULL,
    name_key character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: trust_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE trust_levels_id_seq
    START WITH 3
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: trust_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE trust_levels_id_seq OWNED BY trust_levels.id;


--
-- Name: trust_levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('trust_levels_id_seq', 3, false);


--
-- Name: twitter_user_infos; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE twitter_user_infos (
    id integer NOT NULL,
    user_id integer NOT NULL,
    screen_name character varying(255) NOT NULL,
    twitter_user_id integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: twitter_user_infos_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE twitter_user_infos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: twitter_user_infos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE twitter_user_infos_id_seq OWNED BY twitter_user_infos.id;


--
-- Name: twitter_user_infos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('twitter_user_infos_id_seq', 1, false);


--
-- Name: uploads; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE uploads (
    id integer NOT NULL,
    user_id integer NOT NULL,
    topic_id integer NOT NULL,
    original_filename character varying(255) NOT NULL,
    filesize integer NOT NULL,
    width integer,
    height integer,
    url character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: uploads_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE uploads_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: uploads_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE uploads_id_seq OWNED BY uploads.id;


--
-- Name: uploads_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('uploads_id_seq', 1, false);


--
-- Name: user_actions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_actions (
    id integer NOT NULL,
    action_type integer NOT NULL,
    user_id integer NOT NULL,
    target_topic_id integer,
    target_post_id integer,
    target_user_id integer,
    acting_user_id integer,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: user_actions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_actions_id_seq
    START WITH 24
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_actions_id_seq OWNED BY user_actions.id;


--
-- Name: user_actions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_actions_id_seq', 24, false);


--
-- Name: user_open_ids; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_open_ids (
    id integer NOT NULL,
    user_id integer NOT NULL,
    email character varying(255) NOT NULL,
    url character varying(255) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    active boolean NOT NULL
);


--
-- Name: user_open_ids_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_open_ids_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_open_ids_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_open_ids_id_seq OWNED BY user_open_ids.id;


--
-- Name: user_open_ids_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_open_ids_id_seq', 1, false);


--
-- Name: user_visits; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE user_visits (
    id integer NOT NULL,
    user_id integer NOT NULL,
    visited_at date NOT NULL
);


--
-- Name: user_visits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE user_visits_id_seq
    START WITH 3
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: user_visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE user_visits_id_seq OWNED BY user_visits.id;


--
-- Name: user_visits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('user_visits_id_seq', 3, true);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE users (
    id integer NOT NULL,
    username character varying(20) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    name character varying(255),
    bio_raw text,
    seen_notification_id integer DEFAULT 0 NOT NULL,
    last_posted_at timestamp without time zone,
    email character varying(256) NOT NULL,
    password_hash character varying(64),
    salt character varying(32),
    active boolean,
    username_lower character varying(20) NOT NULL,
    auth_token character varying(32),
    last_seen_at timestamp without time zone,
    website character varying(255),
    admin boolean DEFAULT false NOT NULL,
    moderator boolean DEFAULT false NOT NULL,
    last_emailed_at timestamp without time zone,
    email_digests boolean DEFAULT true NOT NULL,
    trust_level_id integer DEFAULT 1 NOT NULL,
    bio_cooked text,
    email_private_messages boolean DEFAULT true,
    email_direct boolean DEFAULT true NOT NULL,
    approved boolean DEFAULT false NOT NULL,
    approved_by_id integer,
    approved_at timestamp without time zone,
    topics_entered integer DEFAULT 0 NOT NULL,
    posts_read_count integer DEFAULT 0 NOT NULL,
    digest_after_days integer DEFAULT 7 NOT NULL,
    previous_visit_at timestamp without time zone
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE users_id_seq
    START WITH 3
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('users_id_seq', 3, false);


--
-- Name: versions; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE versions (
    id integer NOT NULL,
    versioned_id integer,
    versioned_type character varying(255),
    user_id integer,
    user_type character varying(255),
    user_name character varying(255),
    modifications text,
    number integer,
    reverted_from integer,
    tag character varying(255),
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


--
-- Name: versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE versions_id_seq OWNED BY versions.id;


--
-- Name: versions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('versions_id_seq', 1, false);


--
-- Name: views; Type: TABLE; Schema: public; Owner: -; Tablespace: 
--

CREATE TABLE views (
    parent_id integer NOT NULL,
    parent_type character varying(50) NOT NULL,
    ip bigint NOT NULL,
    viewed_at timestamp without time zone NOT NULL,
    user_id integer
);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY categories ALTER COLUMN id SET DEFAULT nextval('categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY category_featured_users ALTER COLUMN id SET DEFAULT nextval('category_featured_users_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY draft_sequences ALTER COLUMN id SET DEFAULT nextval('draft_sequences_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY drafts ALTER COLUMN id SET DEFAULT nextval('drafts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY email_logs ALTER COLUMN id SET DEFAULT nextval('email_logs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY email_tokens ALTER COLUMN id SET DEFAULT nextval('email_tokens_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY facebook_user_infos ALTER COLUMN id SET DEFAULT nextval('facebook_user_infos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY incoming_links ALTER COLUMN id SET DEFAULT nextval('incoming_links_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY invites ALTER COLUMN id SET DEFAULT nextval('invites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY message_bus ALTER COLUMN id SET DEFAULT nextval('message_bus_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY notifications ALTER COLUMN id SET DEFAULT nextval('notifications_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY onebox_renders ALTER COLUMN id SET DEFAULT nextval('onebox_renders_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY post_action_types ALTER COLUMN id SET DEFAULT nextval('post_action_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY post_actions ALTER COLUMN id SET DEFAULT nextval('post_actions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY posts ALTER COLUMN id SET DEFAULT nextval('posts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY site_customizations ALTER COLUMN id SET DEFAULT nextval('site_customizations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY site_settings ALTER COLUMN id SET DEFAULT nextval('site_settings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topic_allowed_users ALTER COLUMN id SET DEFAULT nextval('topic_allowed_users_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topic_invites ALTER COLUMN id SET DEFAULT nextval('topic_invites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topic_link_clicks ALTER COLUMN id SET DEFAULT nextval('topic_link_clicks_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topic_links ALTER COLUMN id SET DEFAULT nextval('topic_links_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY topics ALTER COLUMN id SET DEFAULT nextval('topics_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY trust_levels ALTER COLUMN id SET DEFAULT nextval('trust_levels_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY twitter_user_infos ALTER COLUMN id SET DEFAULT nextval('twitter_user_infos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY uploads ALTER COLUMN id SET DEFAULT nextval('uploads_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_actions ALTER COLUMN id SET DEFAULT nextval('user_actions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_open_ids ALTER COLUMN id SET DEFAULT nextval('user_open_ids_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY user_visits ALTER COLUMN id SET DEFAULT nextval('user_visits_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY versions ALTER COLUMN id SET DEFAULT nextval('versions_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY categories (id, name, color, topic_id, top1_topic_id, top2_topic_id, top1_user_id, top2_user_id, topic_count, created_at, updated_at, user_id, topics_year, topics_month, topics_week, slug) FROM stdin;
\.


--
-- Data for Name: category_featured_topics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY category_featured_topics (category_id, topic_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: category_featured_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY category_featured_users (id, category_id, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: draft_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY draft_sequences (id, user_id, draft_key, sequence) FROM stdin;
11	2	new_private_message	1
12	2	topic_9	1
\.


--
-- Data for Name: drafts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY drafts (id, user_id, draft_key, data, created_at, updated_at, sequence) FROM stdin;
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY email_logs (id, to_address, email_type, user_id, created_at, updated_at) FROM stdin;
2	neil.lalonde+admin@gmail.com	signup	2	2013-01-07 21:56:05.125091	2013-01-07 21:56:05.125091
\.


--
-- Data for Name: email_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY email_tokens (id, user_id, email, token, confirmed, expired, created_at, updated_at) FROM stdin;
2	2	neil.lalonde+admin@gmail.com	c7b41d0779e2c534bd0eae08a30fd551	t	f	2013-01-07 21:55:41.939804	2013-01-07 21:55:41.939804
\.


--
-- Data for Name: facebook_user_infos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY facebook_user_infos (id, user_id, facebook_user_id, username, first_name, last_name, email, gender, name, link, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: incoming_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY incoming_links (id, url, referer, domain, topic_id, post_number, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY invites (id, invite_key, email, invited_by_id, user_id, redeemed_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: message_bus; Type: TABLE DATA; Schema: public; Owner: -
--

COPY message_bus (id, name, context, data, created_at) FROM stdin;
11716	1	71	{"id":11713,"created_at":"2012-06-22T18:09:58-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":11}	2012-06-22 22:09:58.320615
11717	3	CodingHorror	{"unread_notifications":2}	2012-06-22 22:09:58.350913
11718	1	71	{"id":11714,"created_at":"2012-06-22T20:39:29-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":12}	2012-06-23 00:39:29.218895
11719	3	EvilTrout	{"unread_notifications":1}	2012-06-23 00:39:29.224943
11720	1	73	{"id":11715,"created_at":"2012-06-23T02:52:06-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-06-23 06:52:07.015149
11721	3	EvilTrout	{"unread_notifications":2}	2012-06-23 06:52:07.021408
11722	1	74	{"id":11716,"created_at":"2012-06-23T05:34:35-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-06-23 09:34:35.824247
11725	1	74	{"id":11719,"created_at":"2012-06-23T06:16:03-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-06-23 10:16:03.190243
11726	1	74	{"id":11720,"created_at":"2012-06-23T06:16:24-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":5}	2012-06-23 10:16:24.695591
11727	1	74	{"id":11721,"created_at":"2012-06-23T06:26:20-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":6}	2012-06-23 10:26:20.231228
11728	1	74	{"id":11722,"created_at":"2012-06-23T06:28:11-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":7}	2012-06-23 10:28:11.185922
11730	1	71	{"id":11724,"created_at":"2012-06-23T18:14:05-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":13}	2012-06-23 22:14:05.309694
11731	3	CodingHorror	{"unread_notifications":3}	2012-06-23 22:14:05.315301
11732	1	74	{"id":11725,"created_at":"2012-06-23T18:31:00-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":8}	2012-06-23 22:31:00.458172
11733	1	74	{"id":11726,"created_at":"2012-06-24T01:19:32-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":9}	2012-06-24 05:19:32.81025
11723	1	74	{"id":11717,"created_at":"2012-06-23T06:03:36-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-06-23 10:03:36.790678
11724	1	74	{"id":11718,"created_at":"2012-06-23T06:07:32-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":3}	2012-06-23 10:07:32.185849
11729	1	73	{"id":11723,"created_at":"2012-06-23T18:13:29-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-06-23 22:13:29.696851
11804	new_post	87	{"id":11786,"created_at":"2012-06-28T10:41:54-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-06-28 14:41:54.541236
11813	new_post	88	{"id":11791,"created_at":"2012-06-29T16:18:16-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-06-29 20:18:16.198943
11814	new_post	89	{"id":11792,"created_at":"2012-06-29T16:22:07-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-06-29 20:22:07.906235
11815	new_post	90	{"id":11793,"created_at":"2012-06-29T16:22:28-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-06-29 20:22:28.902269
11818	new_post	88	{"id":11795,"created_at":"2012-06-29T16:29:13-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-06-29 20:29:13.19382
11819	new_user	CodingHorror	{"unread_notifications":1}	2012-06-29 20:29:13.204933
11820	new_post	91	{"id":11796,"created_at":"2012-06-29T16:30:00-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-06-29 20:30:00.376128
11904	new_post	91	{"id":11863,"created_at":"2012-07-03T21:33:15-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":5}	2012-07-04 01:33:15.190353
11905	new_post	96	{"id":11864,"created_at":"2012-07-04T12:03:30-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":4}	2012-07-04 16:03:31.002555
11906	new_post	111	{"id":11865,"created_at":"2012-07-04T16:18:49-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":1}	2012-07-04 20:18:49.129888
11908	new_post	96	{"id":11867,"created_at":"2012-07-05T13:31:05-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":5}	2012-07-05 17:31:05.073292
11909	new_post	91	{"id":11868,"created_at":"2012-07-05T14:22:30-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":7}	2012-07-05 18:22:30.750325
11910	new_post	111	{"id":11869,"created_at":"2012-07-05T16:13:19-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-05 20:13:20.34993
11911	new_user	Hanzo	{"unread_notifications":1}	2012-07-05 20:13:20.442713
11912	new_post	96	{"id":11870,"created_at":"2012-07-05T17:19:48-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":6}	2012-07-05 21:19:48.356437
11913	new_post	97	{"id":11871,"created_at":"2012-07-05T17:20:30-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-05 21:20:30.624974
11914	new_post	112	{"id":11872,"created_at":"2012-07-06T16:44:52-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-06 20:44:52.109542
11915	new_post	112	{"id":11873,"created_at":"2012-07-06T16:49:25-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-06 20:49:25.825256
11916	new_user	EvilTrout	{"unread_notifications":1}	2012-07-06 20:49:25.886163
11917	new_post	113	{"id":11874,"created_at":"2012-07-06T16:52:02-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-06 20:52:02.164988
11918	new_post	96	{"id":11875,"created_at":"2012-07-06T16:54:14-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":6}	2012-07-06 20:54:14.208864
11919	new_post	112	{"id":11876,"created_at":"2012-07-06T18:00:25-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-07-06 22:00:25.491279
11920	new_post	112	{"id":11877,"created_at":"2012-07-06T19:20:55-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-06 23:20:55.842574
11921	new_user	EvilTrout	{"unread_notifications":1}	2012-07-06 23:20:55.985696
11922	new_post	97	{"id":11878,"created_at":"2012-07-06T19:31:55-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-06 23:31:55.791819
11923	new_user	EvilTrout	{"unread_notifications":2}	2012-07-06 23:31:55.935056
11924	new_user	Hanzo	{"unread_notifications":2}	2012-07-06 23:31:55.944404
11925	new_post	112	{"id":11879,"created_at":"2012-07-06T22:52:45-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":5}	2012-07-07 02:52:45.326664
11926	new_post	114	{"id":11880,"created_at":"2012-07-07T12:50:09-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-07 16:50:09.363867
11927	new_post	110	{"id":11881,"created_at":"2012-07-08T13:41:19-04:00","user":{"username":"JackBatty","display_username":"Jack Batty","avatar_url":"/assets/avatars/7.jpg"},"post_number":2}	2012-07-08 17:41:19.546583
11928	new_user	CodingHorror	{"unread_notifications":1}	2012-07-08 17:41:19.606428
11929	new_post	92	{"id":11882,"created_at":"2012-07-08T16:47:24-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":9}	2012-07-08 20:47:24.913105
11930	new_post	91	{"id":11883,"created_at":"2012-07-09T02:39:09-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":8}	2012-07-09 06:39:09.50693
11931	new_post	103	{"id":11884,"created_at":"2012-07-09T07:35:06-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-07-09 11:35:07.201982
11932	new_user	Sam	{"unread_notifications":1}	2012-07-09 11:35:07.451231
11734	1	73	{"id":11727,"created_at":"2012-06-24T02:54:41-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":4}	2012-06-24 06:54:41.455821
11805	new_post	75	{"id":11787,"created_at":"2012-06-28T15:40:14-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":8}	2012-06-28 19:40:14.792771
11806	new_user	Sam	{"unread_notifications":1}	2012-06-28 19:40:14.876051
11816	new_post	88	{"id":11794,"created_at":"2012-06-29T16:27:34-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-06-29 20:27:34.89047
11817	new_user	CodingHorror	{"unread_notifications":1}	2012-06-29 20:27:34.947916
11821	new_post	87	{"id":11797,"created_at":"2012-06-29T16:30:02-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-06-29 20:30:02.90768
11822	new_user	EvilTrout	{"unread_notifications":1}	2012-06-29 20:30:02.924044
11823	new_post	87	{"id":11798,"created_at":"2012-06-29T16:30:33-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-06-29 20:30:33.186799
11824	new_user	EvilTrout	{"unread_notifications":2}	2012-06-29 20:30:33.19735
11907	new_post	91	{"id":11866,"created_at":"2012-07-04T16:26:30-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":6}	2012-07-04 20:26:30.27897
11933	new_post	92	{"id":11885,"created_at":"2012-07-09T07:36:42-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":10}	2012-07-09 11:36:43.007845
11735	1	75	{"id":11728,"created_at":"2012-06-24T03:54:08-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-06-24 07:54:08.621724
11807	new_post	75	{"id":11788,"created_at":"2012-06-28T20:34:21-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":9}	2012-06-29 00:34:21.338136
11808	new_user	Hanzo	{"unread_notifications":1}	2012-06-29 00:34:21.351173
11825	new_post	92	{"id":11799,"created_at":"2012-06-29T16:30:54-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-06-29 20:30:54.55718
11934	new_post	96	{"id":11886,"created_at":"2012-07-09T10:46:44-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":7}	2012-07-09 14:46:44.551223
11935	new_post	114	{"id":11887,"created_at":"2012-07-09T17:44:44-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-09 21:44:45.126271
11936	new_user	CodingHorror	{"unread_notifications":1}	2012-07-09 21:44:45.17325
11937	new_post	115	{"id":11888,"created_at":"2012-07-09T18:46:55-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-07-09 22:46:55.851673
11938	new_post	116	{"id":11889,"created_at":"2012-07-09T19:14:41-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-09 23:14:41.156059
11939	new_post	116	{"id":11890,"created_at":"2012-07-09T19:22:48-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-09 23:22:48.332508
11940	new_user	CodingHorror	{"unread_notifications":1}	2012-07-09 23:22:48.341674
11941	new_post	116	{"id":11891,"created_at":"2012-07-09T19:56:38-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-09 23:56:38.800435
11942	new_post	116	{"id":11892,"created_at":"2012-07-09T20:00:04-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-10 00:00:04.682782
11943	new_post	116	{"id":11893,"created_at":"2012-07-09T20:03:04-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":5}	2012-07-10 00:03:04.744718
11863	new_user	CodingHorror	{"unread_notifications":2}	2012-07-01 04:29:46.951901
11864	new_post	103	{"id":11831,"created_at":"2012-07-01T03:50:57-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-07-01 07:50:57.519535
11944	new_post	117	{"id":11894,"created_at":"2012-07-09T20:25:24-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-10 00:25:24.915596
11945	new_post	117	{"id":11895,"created_at":"2012-07-10T02:18:58-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-10 06:18:59.054752
11946	new_user	CodingHorror	{"unread_notifications":1}	2012-07-10 06:18:59.091299
11947	new_post	92	{"id":11896,"created_at":"2012-07-10T11:32:49-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":11}	2012-07-10 15:32:49.441075
11948	new_post	92	{"id":11897,"created_at":"2012-07-10T11:33:24-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":12}	2012-07-10 15:33:24.779251
11949	new_post	91	{"id":11898,"created_at":"2012-07-10T12:37:48-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":9}	2012-07-10 16:37:48.096307
11950	new_post	96	{"id":11899,"created_at":"2012-07-10T12:40:21-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":8}	2012-07-10 16:40:21.43603
11951	new_post	118	{"id":11900,"created_at":"2012-07-10T12:44:19-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-10 16:44:19.903279
11952	new_post	118	{"id":11901,"created_at":"2012-07-10T16:11:15-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-10 20:11:15.747132
11953	new_user	EvilTrout	{"unread_notifications":1}	2012-07-10 20:11:15.805828
11954	new_post	118	{"id":11902,"created_at":"2012-07-10T16:13:04-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-07-10 20:13:04.790271
11955	new_user	CodingHorror	{"unread_notifications":1}	2012-07-10 20:13:04.82079
11956	new_post	118	{"id":11903,"created_at":"2012-07-10T16:23:32-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-10 20:23:32.918715
11957	new_post	91	{"id":11904,"created_at":"2012-07-10T19:09:02-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":10}	2012-07-10 23:09:02.719132
11958	new_user	EvilTrout	{"unread_notifications":1}	2012-07-10 23:09:02.75841
11959	new_post	114	{"id":11905,"created_at":"2012-07-10T23:19:14-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-11 03:19:14.749812
11960	new_post	114	{"id":11906,"created_at":"2012-07-10T23:24:25-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-11 03:24:25.905469
11961	new_post	114	{"id":11907,"created_at":"2012-07-11T00:14:39-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":4}	2012-07-11 04:14:39.395615
11962	new_post	91	{"id":11908,"created_at":"2012-07-11T00:23:25-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":11}	2012-07-11 04:23:25.36006
11963	new_post	97	{"id":11909,"created_at":"2012-07-11T00:29:18-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":4}	2012-07-11 04:29:18.925261
11964	new_post	115	{"id":11910,"created_at":"2012-07-11T00:35:21-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":2}	2012-07-11 04:35:21.713072
11965	new_user	Sam	{"unread_notifications":1}	2012-07-11 04:35:21.919566
11966	new_post	102	{"id":11911,"created_at":"2012-07-11T00:37:05-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":5}	2012-07-11 04:37:05.764866
11967	new_post	116	{"id":11912,"created_at":"2012-07-11T00:44:48-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":6}	2012-07-11 04:44:48.627944
11736	1	75	{"id":11729,"created_at":"2012-06-24T08:05:57-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-06-24 12:05:57.852063
11737	1	74	{"id":11730,"created_at":"2012-06-24T08:16:02-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":10}	2012-06-24 12:16:02.613809
11809	new_post	87	{"id":11789,"created_at":"2012-06-28T20:38:06-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-06-29 00:38:06.832771
11810	new_user	EvilTrout	{"unread_notifications":1}	2012-06-29 00:38:06.860686
11826	new_post	93	{"id":11800,"created_at":"2012-06-29T17:39:01-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-06-29 21:39:01.994187
11827	new_post	19	{"id":11801,"created_at":"2012-06-29T18:15:03-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":189}	2012-06-29 22:15:03.321298
11828	new_post	94	{"id":11802,"created_at":"2012-06-29T18:23:47-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-06-29 22:23:47.153556
11829	new_post	88	{"id":11803,"created_at":"2012-06-29T18:25:37-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-06-29 22:25:37.987925
11830	new_post	88	{"id":11804,"created_at":"2012-06-29T18:26:58-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":3}	2012-06-29 22:26:58.744018
11832	new_post	87	{"id":11806,"created_at":"2012-06-29T18:30:27-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-06-29 22:30:27.049255
11833	new_post	87	{"id":11807,"created_at":"2012-06-29T18:49:29-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-06-29 22:49:29.470766
11834	new_user	Sam	{"unread_notifications":1}	2012-06-29 22:49:29.481531
11968	new_post	92	{"id":11913,"created_at":"2012-07-11T07:42:53-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":13}	2012-07-11 11:42:53.338443
11970	new_post	116	{"id":11915,"created_at":"2012-07-11T14:16:34-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":7}	2012-07-11 18:16:34.188196
11971	new_user	Hanzo	{"unread_notifications":1}	2012-07-11 18:16:34.207045
12418	new_user	Sam	{"unread_notifications":3}	2012-08-08 13:43:46.047542
11738	1	75	{"id":11731,"created_at":"2012-06-24T10:51:39-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-06-24 14:51:39.447214
11739	3	CodingHorror	{"unread_notifications":4}	2012-06-24 14:51:39.473631
11740	3	Sam	{"unread_notifications":2}	2012-06-24 14:51:39.483726
11811	new_post	87	{"id":11790,"created_at":"2012-06-29T10:15:11-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-06-29 14:15:11.436058
11812	new_user	Sam	{"unread_notifications":1}	2012-06-29 14:15:11.45972
11831	new_post	95	{"id":11805,"created_at":"2012-06-29T18:29:22-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-06-29 22:29:22.368025
11969	new_post	119	{"id":11914,"created_at":"2012-07-11T08:12:06-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-07-11 12:12:06.381826
11972	new_post	96	{"id":11916,"created_at":"2012-07-11T14:36:46-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":9}	2012-07-11 18:36:46.584671
11973	new_post	120	{"id":11917,"created_at":"2012-07-11T16:12:28-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-11 20:12:28.40381
11974	new_post	120	{"id":11918,"created_at":"2012-07-11T16:14:39-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-07-11 20:14:40.15073
11975	new_user	CodingHorror	{"unread_notifications":1}	2012-07-11 20:14:40.271547
11976	new_post	120	{"id":11919,"created_at":"2012-07-11T16:21:55-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-11 20:21:55.902567
11977	new_post	120	{"id":11920,"created_at":"2012-07-11T16:23:05-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-11 20:23:05.05405
11978	new_user	EvilTrout	{"unread_notifications":1}	2012-07-11 20:23:05.087828
11979	new_post	120	{"id":11921,"created_at":"2012-07-11T17:11:00-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":5}	2012-07-11 21:11:01.00541
11980	new_user	CodingHorror	{"unread_notifications":1}	2012-07-11 21:11:01.022255
11981	new_post	120	{"id":11922,"created_at":"2012-07-11T18:03:59-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":6}	2012-07-11 22:03:59.589528
11982	new_post	115	{"id":11923,"created_at":"2012-07-11T18:36:49-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-11 22:36:49.348669
11983	new_user	Hanzo	{"unread_notifications":1}	2012-07-11 22:36:49.409136
11984	new_post	121	{"id":11924,"created_at":"2012-07-11T18:56:53-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-11 22:56:53.686483
11985	new_post	122	{"id":11925,"created_at":"2012-07-11T19:02:20-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-11 23:02:20.216464
11986	new_post	109	{"id":11926,"created_at":"2012-07-11T19:05:32-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-07-11 23:05:32.799161
11987	new_post	92	{"id":11927,"created_at":"2012-07-11T19:06:23-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":14}	2012-07-11 23:06:23.966332
11988	new_post	122	{"id":11928,"created_at":"2012-07-11T19:36:13-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":2}	2012-07-11 23:36:13.867818
11989	new_user	EvilTrout	{"unread_notifications":1}	2012-07-11 23:36:13.880785
11990	new_post	120	{"id":11929,"created_at":"2012-07-11T19:40:09-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":7}	2012-07-11 23:40:09.534721
11991	new_post	119	{"id":11930,"created_at":"2012-07-11T19:45:42-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":2}	2012-07-11 23:45:42.163342
11992	new_user	Sam	{"unread_notifications":1}	2012-07-11 23:45:42.173983
11993	new_post	115	{"id":11931,"created_at":"2012-07-11T19:47:35-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":4}	2012-07-11 23:47:35.317795
11994	new_user	CodingHorror	{"unread_notifications":1}	2012-07-11 23:47:35.334347
11995	new_post	83	{"id":11932,"created_at":"2012-07-11T19:55:36-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":5}	2012-07-11 23:55:36.767498
11996	new_user	CodingHorror	{"unread_notifications":1}	2012-07-11 23:55:36.794073
11997	new_post	83	{"id":11933,"created_at":"2012-07-11T20:28:30-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":6}	2012-07-12 00:28:30.578666
11998	new_user	Hanzo	{"unread_notifications":1}	2012-07-12 00:28:30.590837
11999	new_post	123	{"id":11934,"created_at":"2012-07-11T20:30:05-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-12 00:30:05.781428
12000	new_post	92	{"id":11935,"created_at":"2012-07-12T03:28:33-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":15}	2012-07-12 07:28:33.186249
12001	new_post	122	{"id":11936,"created_at":"2012-07-12T05:56:53-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-12 09:56:53.792275
12002	new_post	123	{"id":11937,"created_at":"2012-07-12T11:08:07-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-07-12 15:08:07.813484
12003	new_user	CodingHorror	{"unread_notifications":1}	2012-07-12 15:08:07.945366
12004	new_post	123	{"id":11938,"created_at":"2012-07-12T11:11:56-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":3}	2012-07-12 15:11:56.820214
12005	new_post	92	{"id":11939,"created_at":"2012-07-12T11:13:28-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":16}	2012-07-12 15:13:28.901474
12063	new_user	Hanzo	{"unread_notifications":2}	2012-07-16 16:55:35.486955
12006	new_post	119	{"id":11940,"created_at":"2012-07-12T11:33:19-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":3}	2012-07-12 15:33:19.135604
11741	1	76	{"id":11732,"created_at":"2012-06-24T12:52:44-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-06-24 16:52:44.535849
11745	1	75	{"id":11736,"created_at":"2012-06-24T15:28:57-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":4}	2012-06-24 19:28:57.125992
11747	1	74	{"id":11738,"created_at":"2012-06-24T19:27:47-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":12}	2012-06-24 23:27:47.378973
11748	1	76	{"id":11739,"created_at":"2012-06-24T19:30:23-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":5}	2012-06-24 23:30:23.137865
11749	1	74	{"id":11740,"created_at":"2012-06-24T19:31:46-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":13}	2012-06-24 23:31:46.331134
11750	3	CodingHorror	{"unread_notifications":5}	2012-06-24 23:31:46.346059
11835	new_post	87	{"id":11808,"created_at":"2012-06-29T18:51:21-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":4}	2012-06-29 22:51:21.699602
11836	new_user	EvilTrout	{"unread_notifications":1}	2012-06-29 22:51:21.738719
11843	new_post	94	{"id":11813,"created_at":"2012-06-30T05:04:57-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-06-30 09:04:57.116049
11850	new_post	98	{"id":11819,"created_at":"2012-06-30T12:08:13-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-06-30 16:08:13.519686
11851	new_post	99	{"id":11820,"created_at":"2012-06-30T14:38:17-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-06-30 18:38:17.764209
11852	new_post	99	{"id":11821,"created_at":"2012-06-30T18:24:14-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-06-30 22:24:14.578534
11867	new_post	100	{"id":11833,"created_at":"2012-07-01T05:03:16-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-01 09:03:16.522681
11868	new_post	87	{"id":11834,"created_at":"2012-07-01T05:39:04-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-01 09:39:04.15569
12007	new_post	116	{"id":11941,"created_at":"2012-07-12T11:52:25-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":8}	2012-07-12 15:52:25.50806
12008	new_post	116	{"id":11942,"created_at":"2012-07-12T11:56:54-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":9}	2012-07-12 15:56:54.446431
11742	1	76	{"id":11733,"created_at":"2012-06-24T14:08:23-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":2}	2012-06-24 18:08:23.459656
11743	1	76	{"id":11734,"created_at":"2012-06-24T14:08:52-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-06-24 18:08:52.532519
11744	1	74	{"id":11735,"created_at":"2012-06-24T15:14:32-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":11}	2012-06-24 19:14:32.33187
11751	1	74	{"id":11741,"created_at":"2012-06-24T19:37:34-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":14}	2012-06-24 23:37:34.505125
11752	1	75	{"id":11742,"created_at":"2012-06-24T19:47:13-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":5}	2012-06-24 23:47:13.090175
11754	1	75	{"id":11744,"created_at":"2012-06-24T20:58:14-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":6}	2012-06-25 00:58:14.561771
11837	new_post	96	{"id":11809,"created_at":"2012-06-29T18:51:57-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-06-29 22:51:57.770993
11838	new_post	91	{"id":11810,"created_at":"2012-06-29T18:57:02-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-06-29 22:57:02.913033
11841	new_post	95	{"id":11812,"created_at":"2012-06-30T05:02:04-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-06-30 09:02:04.111057
11842	new_user	Sam	{"unread_notifications":1}	2012-06-30 09:02:04.137584
11844	new_post	87	{"id":11814,"created_at":"2012-06-30T05:13:18-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-06-30 09:13:18.147494
11845	new_post	97	{"id":11815,"created_at":"2012-06-30T05:21:54-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-06-30 09:21:54.621752
11846	new_post	92	{"id":11816,"created_at":"2012-06-30T05:25:47-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-06-30 09:25:47.160513
11854	new_post	101	{"id":11823,"created_at":"2012-06-30T19:35:51-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":1}	2012-06-30 23:35:51.587111
11855	new_post	102	{"id":11824,"created_at":"2012-06-30T20:55:14-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-07-01 00:55:14.65527
11857	new_post	92	{"id":11826,"created_at":"2012-06-30T21:08:37-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-01 01:08:37.969341
11860	new_post	100	{"id":11829,"created_at":"2012-07-01T00:25:11-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":3}	2012-07-01 04:25:11.022732
11861	new_user	CodingHorror	{"unread_notifications":1}	2012-07-01 04:25:11.031665
11862	new_post	101	{"id":11830,"created_at":"2012-07-01T00:29:46-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":3}	2012-07-01 04:29:46.940557
12009	new_post	114	{"id":11943,"created_at":"2012-07-12T14:32:05-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":5}	2012-07-12 18:32:06.026094
12010	new_post	114	{"id":11944,"created_at":"2012-07-12T14:34:48-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":6}	2012-07-12 18:34:48.776076
12011	new_user	Hanzo	{"unread_notifications":1}	2012-07-12 18:34:48.842366
12012	new_post	39	{"id":11945,"created_at":"2012-07-12T15:35:59-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":187}	2012-07-12 19:35:59.422328
12013	new_user	Nava	{"unread_notifications":1}	2012-07-12 19:35:59.457179
12014	new_user	DreadPirateJimbo	{"unread_notifications":1}	2012-07-12 19:35:59.463682
12015	new_post	39	{"id":11946,"created_at":"2012-07-12T15:37:59-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":188}	2012-07-12 19:37:59.135578
12016	new_user	OrcaEyes	{"unread_notifications":1}	2012-07-12 19:37:59.227497
12017	new_post	39	{"id":11947,"created_at":"2012-07-12T15:38:16-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":189}	2012-07-12 19:38:16.588099
12018	new_user	OrcaEyes	{"unread_notifications":2}	2012-07-12 19:38:16.602147
12019	new_post	96	{"id":11948,"created_at":"2012-07-12T15:41:12-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":10}	2012-07-12 19:41:12.584138
12020	new_post	114	{"id":11949,"created_at":"2012-07-12T16:58:51-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":7}	2012-07-12 20:58:51.826568
12021	new_post	114	{"id":11950,"created_at":"2012-07-12T17:24:13-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":8}	2012-07-12 21:24:13.310194
12022	new_user	EvilTrout	{"unread_notifications":1}	2012-07-12 21:24:13.33529
12023	new_post	114	{"id":11951,"created_at":"2012-07-12T18:29:17-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":9}	2012-07-12 22:29:17.295304
12024	new_user	CodingHorror	{"unread_notifications":1}	2012-07-12 22:29:17.321776
12025	new_post	114	{"id":11952,"created_at":"2012-07-12T19:05:38-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":10}	2012-07-12 23:05:38.761329
12026	new_user	CodingHorror	{"unread_notifications":1}	2012-07-12 23:05:38.795802
12027	new_post	124	{"id":11953,"created_at":"2012-07-12T19:19:52-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":1}	2012-07-12 23:19:52.199593
11746	1	76	{"id":11737,"created_at":"2012-06-24T15:31:52-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":4}	2012-06-24 19:31:52.375068
11753	1	74	{"id":11743,"created_at":"2012-06-24T20:30:58-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":15}	2012-06-25 00:30:58.828248
11839	new_post	88	{"id":11811,"created_at":"2012-06-29T18:57:45-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":4}	2012-06-29 22:57:45.045676
11840	new_user	Sam	{"unread_notifications":2}	2012-06-29 22:57:45.068579
11847	new_post	97	{"id":11817,"created_at":"2012-06-30T12:02:02-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-06-30 16:02:02.851744
11848	new_user	CodingHorror	{"unread_notifications":1}	2012-06-30 16:02:02.860855
11849	new_post	92	{"id":11818,"created_at":"2012-06-30T12:03:52-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-06-30 16:03:52.582531
11853	new_post	100	{"id":11822,"created_at":"2012-06-30T19:26:03-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":1}	2012-06-30 23:26:03.700276
11856	new_post	98	{"id":11825,"created_at":"2012-06-30T21:07:10-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-01 01:07:10.532693
11858	new_post	100	{"id":11827,"created_at":"2012-06-30T21:11:20-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-01 01:11:20.905723
11859	new_post	101	{"id":11828,"created_at":"2012-06-30T21:15:12-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-01 01:15:12.331955
11865	new_post	101	{"id":11832,"created_at":"2012-07-01T04:55:14-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-01 08:55:14.465348
11866	new_user	Hanzo	{"unread_notifications":1}	2012-07-01 08:55:14.473189
12028	new_post	114	{"id":11954,"created_at":"2012-07-13T01:24:57-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":11}	2012-07-13 05:24:58.031099
12029	new_user	EvilTrout	{"unread_notifications":1}	2012-07-13 05:24:58.057896
11755	1	77	{"id":11745,"created_at":"2012-06-25T02:53:38-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-06-25 06:53:38.141494
11757	1	79	{"id":11747,"created_at":"2012-06-25T03:00:41-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-06-25 07:00:41.895468
11759	1	79	{"id":11749,"created_at":"2012-06-25T03:04:21-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":3}	2012-06-25 07:04:21.054362
11761	1	79	{"id":11751,"created_at":"2012-06-25T03:07:41-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":5}	2012-06-25 07:07:41.153937
11763	1	79	{"id":11753,"created_at":"2012-06-25T03:11:17-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":7}	2012-06-25 07:11:17.358126
11764	1	79	{"id":11754,"created_at":"2012-06-25T03:13:32-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":8}	2012-06-25 07:13:32.317636
11765	1	79	{"id":11755,"created_at":"2012-06-25T03:15:10-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":9}	2012-06-25 07:15:10.742633
11766	1	75	{"id":11756,"created_at":"2012-06-25T03:16:50-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":7}	2012-06-25 07:16:50.581243
11869	new_post	104	{"id":11835,"created_at":"2012-07-01T23:42:27-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-02 03:42:27.270215
12030	new_post	96	{"id":11955,"created_at":"2012-07-13T14:03:19-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":11}	2012-07-13 18:03:19.277568
12031	new_post	119	{"id":11956,"created_at":"2012-07-14T16:14:53-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-14 20:14:53.574995
12032	new_user	Hanzo	{"unread_notifications":1}	2012-07-14 20:14:53.650449
12033	new_post	119	{"id":11957,"created_at":"2012-07-14T16:22:15-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":5}	2012-07-14 20:22:15.420502
12034	new_user	Sam	{"unread_notifications":1}	2012-07-14 20:22:15.468647
12035	new_post	119	{"id":11958,"created_at":"2012-07-14T23:26:30-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":6}	2012-07-15 03:26:30.603969
12036	new_user	CodingHorror	{"unread_notifications":1}	2012-07-15 03:26:30.64419
12037	new_post	125	{"id":11959,"created_at":"2012-07-14T23:27:56-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-07-15 03:27:56.836678
12038	new_post	126	{"id":11960,"created_at":"2012-07-15T01:26:09-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-07-15 05:26:09.581237
12039	new_post	125	{"id":11961,"created_at":"2012-07-15T13:53:30-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-15 17:53:30.385245
12040	new_user	Sam	{"unread_notifications":1}	2012-07-15 17:53:30.525124
12041	new_post	125	{"id":11962,"created_at":"2012-07-15T13:55:14-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-15 17:55:14.881578
12042	new_user	Sam	{"unread_notifications":2}	2012-07-15 17:55:14.960896
12043	new_post	119	{"id":11963,"created_at":"2012-07-15T13:56:03-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":7}	2012-07-15 17:56:03.858486
12044	new_user	Sam	{"unread_notifications":3}	2012-07-15 17:56:03.888322
12045	new_post	92	{"id":11964,"created_at":"2012-07-15T13:57:15-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":17}	2012-07-15 17:57:15.627135
12046	new_post	121	{"id":11965,"created_at":"2012-07-15T14:06:56-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-15 18:06:56.466113
12047	new_user	EvilTrout	{"unread_notifications":1}	2012-07-15 18:06:56.494151
12048	new_post	92	{"id":11966,"created_at":"2012-07-15T14:10:06-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":18}	2012-07-15 18:10:07.036919
12049	new_post	127	{"id":11967,"created_at":"2012-07-15T14:13:12-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-15 18:13:12.366616
12050	new_post	127	{"id":11968,"created_at":"2012-07-15T22:49:45-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":2}	2012-07-16 02:49:45.484577
12051	new_user	CodingHorror	{"unread_notifications":1}	2012-07-16 02:49:45.563755
12052	new_post	119	{"id":11969,"created_at":"2012-07-15T22:53:07-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":8}	2012-07-16 02:53:07.579014
12053	new_user	CodingHorror	{"unread_notifications":2}	2012-07-16 02:53:07.624211
12054	new_post	119	{"id":11970,"created_at":"2012-07-15T22:58:32-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":9}	2012-07-16 02:58:32.448572
12055	new_user	CodingHorror	{"unread_notifications":3}	2012-07-16 02:58:32.496655
12056	new_post	114	{"id":11971,"created_at":"2012-07-15T23:07:36-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":12}	2012-07-16 03:07:37.00543
12057	new_user	EvilTrout	{"unread_notifications":2}	2012-07-16 03:07:37.020498
12058	new_post	119	{"id":11972,"created_at":"2012-07-16T01:34:22-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":10}	2012-07-16 05:34:22.204236
12059	new_user	Hanzo	{"unread_notifications":1}	2012-07-16 05:34:22.357383
12060	new_post	127	{"id":11973,"created_at":"2012-07-16T10:58:36-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-07-16 14:58:36.139372
12061	new_post	96	{"id":11974,"created_at":"2012-07-16T11:31:41-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":12}	2012-07-16 15:31:41.384253
12062	new_post	127	{"id":11975,"created_at":"2012-07-16T12:55:35-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-16 16:55:35.408645
11756	1	78	{"id":11746,"created_at":"2012-06-25T02:59:26-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-06-25 06:59:26.573383
11758	1	79	{"id":11748,"created_at":"2012-06-25T03:03:20-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-06-25 07:03:20.891886
11760	1	79	{"id":11750,"created_at":"2012-06-25T03:06:14-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":4}	2012-06-25 07:06:14.641216
11762	1	79	{"id":11752,"created_at":"2012-06-25T03:09:51-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":6}	2012-06-25 07:09:51.053286
11870	new_post	105	{"id":11836,"created_at":"2012-07-02T02:08:35-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-02 06:08:35.513322
11767	1	80	{"id":11757,"created_at":"2012-06-25T03:22:35-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-06-25 07:22:35.856294
11871	new_post	102	{"id":11837,"created_at":"2012-07-02T02:35:06-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-02 06:35:06.067367
11872	new_user	Sam	{"unread_notifications":1}	2012-07-02 06:35:06.153215
12064	new_post	127	{"id":11976,"created_at":"2012-07-16T17:31:46-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":5}	2012-07-16 21:31:46.114834
12065	new_post	127	{"id":11977,"created_at":"2012-07-16T21:02:02-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":6}	2012-07-17 01:02:02.273954
12066	new_user	CodingHorror	{"unread_notifications":1}	2012-07-17 01:02:02.355797
12067	new_post	119	{"id":11978,"created_at":"2012-07-16T21:05:06-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":11}	2012-07-17 01:05:06.693506
12068	new_user	CodingHorror	{"unread_notifications":2}	2012-07-17 01:05:06.712502
12069	new_post	96	{"id":11979,"created_at":"2012-07-17T04:02:15-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":13}	2012-07-17 08:02:16.045389
12070	new_post	92	{"id":11980,"created_at":"2012-07-17T05:34:49-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":19}	2012-07-17 09:34:49.174939
12071	new_post	119	{"id":11981,"created_at":"2012-07-17T05:36:22-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":12}	2012-07-17 09:36:22.71251
12072	new_user	Hanzo	{"unread_notifications":1}	2012-07-17 09:36:22.807649
12073	new_post	127	{"id":11982,"created_at":"2012-07-17T05:37:48-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":7}	2012-07-17 09:37:48.582721
12074	new_user	CodingHorror	{"unread_notifications":3}	2012-07-17 09:37:48.629072
12075	new_post	128	{"id":11983,"created_at":"2012-07-17T05:52:23-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-07-17 09:52:23.071441
12076	new_post	119	{"id":11984,"created_at":"2012-07-17T12:09:34-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":13}	2012-07-17 16:09:34.653249
12077	new_user	Hanzo	{"unread_notifications":2}	2012-07-17 16:09:34.700612
12078	new_post	128	{"id":11985,"created_at":"2012-07-17T12:21:52-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-07-17 16:21:52.572993
12079	new_user	Sam	{"unread_notifications":1}	2012-07-17 16:21:52.629165
12080	new_post	96	{"id":11986,"created_at":"2012-07-17T12:22:59-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":14}	2012-07-17 16:22:59.510074
12081	new_post	128	{"id":11987,"created_at":"2012-07-18T00:33:57-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-18 04:33:57.366827
12082	new_post	128	{"id":11988,"created_at":"2012-07-18T01:12:18-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":4}	2012-07-18 05:12:18.139419
12083	new_user	EvilTrout	{"unread_notifications":1}	2012-07-18 05:12:18.209948
12084	new_user	CodingHorror	{"unread_notifications":1}	2012-07-18 05:12:18.221261
12085	new_post	128	{"id":11989,"created_at":"2012-07-18T01:21:07-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":5}	2012-07-18 05:21:07.131704
12086	new_user	Sam	{"unread_notifications":1}	2012-07-18 05:21:07.17414
12087	new_post	128	{"id":11990,"created_at":"2012-07-18T01:54:46-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":6}	2012-07-18 05:54:46.751319
12088	new_user	CodingHorror	{"unread_notifications":1}	2012-07-18 05:54:46.800904
12089	new_post	129	{"id":11991,"created_at":"2012-07-18T03:44:22-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-07-18 07:44:22.637436
12090	new_post	92	{"id":11992,"created_at":"2012-07-18T03:45:17-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":20}	2012-07-18 07:45:17.572531
12091	new_post	92	{"id":11993,"created_at":"2012-07-18T03:48:54-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":21}	2012-07-18 07:48:54.719005
12092	new_post	129	{"id":11994,"created_at":"2012-07-18T10:33:33-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-07-18 14:33:33.147218
12093	new_user	Sam	{"unread_notifications":1}	2012-07-18 14:33:33.198825
12094	new_post	96	{"id":11995,"created_at":"2012-07-18T10:59:06-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":15}	2012-07-18 14:59:06.287718
12095	new_post	92	{"id":11996,"created_at":"2012-07-18T11:19:15-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":22}	2012-07-18 15:19:15.204151
12096	new_user	Sam	{"unread_notifications":1}	2012-07-18 15:19:15.293943
12097	new_post	119	{"id":11997,"created_at":"2012-07-18T11:38:07-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":14}	2012-07-18 15:38:07.653213
12098	new_user	CodingHorror	{"unread_notifications":1}	2012-07-18 15:38:07.701876
12099	new_post	124	{"id":11998,"created_at":"2012-07-18T12:49:01-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":2}	2012-07-18 16:49:01.39185
12100	new_post	129	{"id":11999,"created_at":"2012-07-18T18:26:32-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-18 22:26:32.893425
12102	new_post	130	{"id":12001,"created_at":"2012-07-18T18:41:28-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-07-18 22:41:28.692087
12103	new_user	Hanzo	{"unread_notifications":1}	2012-07-18 22:41:28.773223
12106	new_post	96	{"id":12004,"created_at":"2012-07-19T11:15:53-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":16}	2012-07-19 15:15:53.251333
12322	new_user	CodingHorror	{"unread_notifications":1}	2012-08-03 21:23:01.65543
12107	new_post	96	{"id":12005,"created_at":"2012-07-20T12:48:03-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":17}	2012-07-20 16:48:03.507202
11768	1	79	{"id":11758,"created_at":"2012-06-25T06:01:21-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":10}	2012-06-25 10:01:21.327085
11769	1	80	{"id":11759,"created_at":"2012-06-25T06:02:29-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-06-25 10:02:29.179761
11770	1	80	{"id":11760,"created_at":"2012-06-25T09:36:42-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-06-25 13:36:42.699079
11873	new_post	87	{"id":11838,"created_at":"2012-07-02T03:30:55-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-02 07:30:55.886228
11874	new_user	CodingHorror	{"unread_notifications":1}	2012-07-02 07:30:55.920082
12101	new_post	130	{"id":12000,"created_at":"2012-07-18T18:26:55-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":1}	2012-07-18 22:26:55.431748
12104	new_post	130	{"id":12002,"created_at":"2012-07-18T18:42:38-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-18 22:42:38.312978
12105	new_post	124	{"id":12003,"created_at":"2012-07-19T01:45:27-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":3}	2012-07-19 05:45:27.106
12108	new_post	131	{"id":12006,"created_at":"2012-07-20T19:44:50-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-20 23:44:50.37736
12112	new_post	132	{"id":12010,"created_at":"2012-07-21T14:33:23-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":3}	2012-07-21 18:33:23.696928
12113	new_user	CodingHorror	{"unread_notifications":1}	2012-07-21 18:33:23.772948
11771	1	80	{"id":11761,"created_at":"2012-06-25T14:44:30-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":4}	2012-06-25 18:44:30.888247
11772	1	78	{"id":11762,"created_at":"2012-06-25T14:54:30-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-06-25 18:54:30.810924
11773	1	77	{"id":11763,"created_at":"2012-06-25T14:56:25-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-06-25 18:56:25.255524
11875	new_post	102	{"id":11839,"created_at":"2012-07-02T04:03:22-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":3}	2012-07-02 08:03:22.659434
11876	new_user	CodingHorror	{"unread_notifications":1}	2012-07-02 08:03:22.722626
11877	new_post	100	{"id":11840,"created_at":"2012-07-02T04:08:32-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":5}	2012-07-02 08:08:32.221345
11878	new_user	CodingHorror	{"unread_notifications":2}	2012-07-02 08:08:32.234088
12109	new_post	132	{"id":12007,"created_at":"2012-07-21T01:48:15-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-21 05:48:15.350681
12110	new_post	132	{"id":12008,"created_at":"2012-07-21T01:49:53-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-21 05:49:53.312258
12111	new_post	92	{"id":12009,"created_at":"2012-07-21T01:54:20-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":22}	2012-07-21 05:54:21.009476
12114	new_post	132	{"id":12011,"created_at":"2012-07-21T22:02:47-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-22 02:02:47.386953
12115	new_user	Hanzo	{"unread_notifications":1}	2012-07-22 02:02:47.435027
12116	new_post	91	{"id":12012,"created_at":"2012-07-22T00:53:20-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":12}	2012-07-22 04:53:21.415525
12117	new_post	92	{"id":12013,"created_at":"2012-07-22T22:02:29-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":23}	2012-07-23 02:02:29.543338
12118	new_post	133	{"id":12014,"created_at":"2012-07-22T22:26:01-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-23 02:26:01.262805
12119	new_post	133	{"id":12015,"created_at":"2012-07-22T23:09:43-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-07-23 03:09:43.34421
12120	new_user	EvilTrout	{"unread_notifications":1}	2012-07-23 03:09:43.389759
12121	new_post	133	{"id":12016,"created_at":"2012-07-22T23:10:56-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":3}	2012-07-23 03:10:56.409476
12122	new_user	EvilTrout	{"unread_notifications":2}	2012-07-23 03:10:56.428092
12123	new_post	133	{"id":12017,"created_at":"2012-07-23T02:41:49-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":4}	2012-07-23 06:41:50.001762
12124	new_user	EvilTrout	{"unread_notifications":3}	2012-07-23 06:41:50.094263
12125	new_post	133	{"id":12018,"created_at":"2012-07-23T02:43:06-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":5}	2012-07-23 06:43:06.823311
12126	new_user	EvilTrout	{"unread_notifications":4}	2012-07-23 06:43:06.926285
12127	new_post	133	{"id":12019,"created_at":"2012-07-23T02:51:14-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":6}	2012-07-23 06:51:14.310706
12128	new_user	EvilTrout	{"unread_notifications":5}	2012-07-23 06:51:14.326425
12129	new_post	134	{"id":12020,"created_at":"2012-07-23T03:06:02-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-07-23 07:06:02.979082
12130	new_post	133	{"id":12021,"created_at":"2012-07-23T04:27:31-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":7}	2012-07-23 08:27:31.2378
12131	new_post	132	{"id":12022,"created_at":"2012-07-23T09:41:55-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":5}	2012-07-23 13:41:56.038156
12132	new_user	CodingHorror	{"unread_notifications":1}	2012-07-23 13:41:56.185752
12465	new_user	BarkisisWillin'	{"unread_notifications":1}	2012-08-09 18:50:34.383091
12133	new_post	96	{"id":12023,"created_at":"2012-07-23T12:12:28-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":18}	2012-07-23 16:12:28.043117
12134	new_post	133	{"id":12024,"created_at":"2012-07-23T13:15:18-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":8}	2012-07-23 17:15:18.9889
12135	new_user	Sam	{"unread_notifications":1}	2012-07-23 17:15:19.229184
12136	new_post	132	{"id":12025,"created_at":"2012-07-23T15:09:09-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":6}	2012-07-23 19:09:10.149037
12137	new_post	134	{"id":12026,"created_at":"2012-07-23T15:15:17-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-23 19:15:17.773657
12138	new_user	Sam	{"unread_notifications":2}	2012-07-23 19:15:18.052194
12139	new_post	134	{"id":12027,"created_at":"2012-07-23T15:43:51-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":3}	2012-07-23 19:43:51.692815
12140	new_user	CodingHorror	{"unread_notifications":1}	2012-07-23 19:43:51.717733
12141	new_post	132	{"id":12028,"created_at":"2012-07-23T15:47:56-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":7}	2012-07-23 19:47:56.354111
12142	new_user	CodingHorror	{"unread_notifications":2}	2012-07-23 19:47:56.378562
12143	new_post	91	{"id":12029,"created_at":"2012-07-23T17:23:18-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":13}	2012-07-23 21:23:18.468821
12144	new_post	125	{"id":12030,"created_at":"2012-07-23T17:51:49-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-23 21:51:49.378405
12145	new_post	134	{"id":12031,"created_at":"2012-07-23T19:23:52-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-23 23:23:52.433695
12146	new_user	Hanzo	{"unread_notifications":1}	2012-07-23 23:23:52.510203
12147	new_post	114	{"id":12032,"created_at":"2012-07-23T19:44:14-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":13}	2012-07-23 23:44:14.683359
11774	1	81	{"id":11764,"created_at":"2012-06-25T19:25:32-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-06-25 23:25:33.045437
11775	3	CodingHorror	{"unread_notifications":1}	2012-06-25 23:25:33.077188
11776	1	81	{"id":11765,"created_at":"2012-06-25T19:26:45-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-06-25 23:26:45.343203
11879	new_post	100	{"id":11841,"created_at":"2012-07-02T04:10:09-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":6}	2012-07-02 08:10:09.279346
12148	new_user	Hanzo	{"unread_notifications":2}	2012-07-23 23:44:14.700965
12153	new_post	136	{"id":12037,"created_at":"2012-07-23T20:49:25-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-24 00:49:25.114521
11777	1	82	{"id":11766,"created_at":"2012-06-25T20:32:54-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-06-26 00:32:54.097964
11880	new_post	96	{"id":11842,"created_at":"2012-07-02T10:12:54-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-07-02 14:12:54.11304
12149	new_post	124	{"id":12033,"created_at":"2012-07-23T19:49:35-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-23 23:49:35.181253
12150	new_post	91	{"id":12034,"created_at":"2012-07-23T20:05:10-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":14}	2012-07-24 00:05:10.158363
12151	new_post	92	{"id":12035,"created_at":"2012-07-23T20:06:57-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":24}	2012-07-24 00:06:57.744755
12152	new_post	135	{"id":12036,"created_at":"2012-07-23T20:16:23-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-24 00:16:23.305374
12154	new_post	132	{"id":12038,"created_at":"2012-07-24T10:32:39-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":8}	2012-07-24 14:32:40.112101
12155	new_post	96	{"id":12039,"created_at":"2012-07-24T11:17:18-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":19}	2012-07-24 15:17:18.845501
12156	new_post	137	{"id":12040,"created_at":"2012-07-24T13:45:17-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-24 17:45:17.975765
12157	new_post	132	{"id":12041,"created_at":"2012-07-24T14:34:28-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":9}	2012-07-24 18:34:28.677259
12158	new_user	EvilTrout	{"unread_notifications":1}	2012-07-24 18:34:28.729423
12159	new_post	114	{"id":12042,"created_at":"2012-07-24T15:11:11-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":14}	2012-07-24 19:11:11.516647
12160	new_user	CodingHorror	{"unread_notifications":1}	2012-07-24 19:11:11.544148
12161	new_post	132	{"id":12043,"created_at":"2012-07-24T15:12:29-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":10}	2012-07-24 19:12:29.670412
12162	new_user	CodingHorror	{"unread_notifications":2}	2012-07-24 19:12:29.691368
12163	new_post	136	{"id":12044,"created_at":"2012-07-24T15:33:14-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":2}	2012-07-24 19:33:14.390383
12164	new_user	CodingHorror	{"unread_notifications":3}	2012-07-24 19:33:14.516329
12165	new_post	137	{"id":12045,"created_at":"2012-07-24T15:36:03-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":2}	2012-07-24 19:36:03.127715
12166	new_user	EvilTrout	{"unread_notifications":1}	2012-07-24 19:36:03.146269
12167	new_post	124	{"id":12046,"created_at":"2012-07-24T17:10:19-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":5}	2012-07-24 21:10:19.178995
12168	new_user	CodingHorror	{"unread_notifications":1}	2012-07-24 21:10:19.196753
12169	new_post	137	{"id":12047,"created_at":"2012-07-24T17:20:38-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":3}	2012-07-24 21:20:38.089248
12170	new_user	EvilTrout	{"unread_notifications":1}	2012-07-24 21:20:38.137303
12171	new_post	137	{"id":12048,"created_at":"2012-07-24T19:10:12-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-24 23:10:12.802768
12172	new_user	Hanzo	{"unread_notifications":1}	2012-07-24 23:10:12.844319
12173	new_post	92	{"id":12049,"created_at":"2012-07-24T19:12:05-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":25}	2012-07-24 23:12:05.278643
12174	new_post	137	{"id":12050,"created_at":"2012-07-24T19:29:50-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":5}	2012-07-24 23:29:50.477666
12175	new_post	137	{"id":12051,"created_at":"2012-07-24T23:09:01-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":6}	2012-07-25 03:09:02.278587
12176	new_post	120	{"id":12052,"created_at":"2012-07-25T00:09:04-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":8}	2012-07-25 04:09:04.711861
12177	new_user	Hanzo	{"unread_notifications":2}	2012-07-25 04:09:04.760754
12178	new_post	120	{"id":12053,"created_at":"2012-07-25T00:40:31-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":9}	2012-07-25 04:40:31.183506
12179	new_user	CodingHorror	{"unread_notifications":1}	2012-07-25 04:40:31.224853
12180	new_post	134	{"id":12054,"created_at":"2012-07-25T04:55:30-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":5}	2012-07-25 08:55:31.071649
12181	new_post	138	{"id":12055,"created_at":"2012-07-25T08:09:35-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-07-25 12:09:35.912615
12182	new_post	124	{"id":12056,"created_at":"2012-07-25T08:16:59-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":6}	2012-07-25 12:16:59.209527
12183	new_post	137	{"id":12057,"created_at":"2012-07-25T09:45:41-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":7}	2012-07-25 13:45:41.781166
12184	new_post	96	{"id":12058,"created_at":"2012-07-25T12:56:14-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":20}	2012-07-25 16:56:15.004431
12185	new_post	19	{"id":12059,"created_at":"2012-07-25T13:43:47-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":186}	2012-07-25 17:43:47.496778
12186	new_user	Indistinguishable	{"unread_notifications":1}	2012-07-25 17:43:47.598137
12187	new_post	134	{"id":12060,"created_at":"2012-07-25T15:28:23-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":6}	2012-07-25 19:28:24.326617
12188	new_user	Sam	{"unread_notifications":1}	2012-07-25 19:28:24.66721
12189	new_post	138	{"id":12061,"created_at":"2012-07-25T16:34:28-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-25 20:34:28.912808
12190	new_user	Sam	{"unread_notifications":2}	2012-07-25 20:34:28.993669
11778	1	83	{"id":11767,"created_at":"2012-06-25T22:01:18-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-06-26 02:01:18.884625
11881	new_post	106	{"id":11843,"created_at":"2012-07-02T10:13:47-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-02 14:13:47.272202
11882	new_post	100	{"id":11844,"created_at":"2012-07-02T10:55:47-04:00","user":{"username":"Hanzo","display_username":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":7}	2012-07-02 14:55:48.013794
12191	new_post	19	{"id":12062,"created_at":"2012-07-25T18:05:10-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":186}	2012-07-25 22:05:10.805627
11779	1	84	{"id":11768,"created_at":"2012-06-25T22:35:58-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-06-26 02:35:58.936297
11883	new_post	100	{"id":11845,"created_at":"2012-07-02T14:51:54-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":8}	2012-07-02 18:51:54.073206
11884	new_user	Hanzo	{"unread_notifications":1}	2012-07-02 18:51:54.103229
12192	new_post	19	{"id":12063,"created_at":"2012-07-25T18:06:07-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":186}	2012-07-25 22:06:07.344938
12193	new_post	19	{"id":12064,"created_at":"2012-07-25T18:06:27-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":186}	2012-07-25 22:06:27.171783
12194	new_post	19	{"id":12065,"created_at":"2012-07-25T18:07:57-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":186}	2012-07-25 22:07:57.909921
12195	new_post	139	{"id":12066,"created_at":"2012-07-26T00:11:21-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-07-26 04:11:21.442922
12196	new_post	92	{"id":12067,"created_at":"2012-07-26T00:21:14-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":26}	2012-07-26 04:21:14.08471
12197	new_post	140	{"id":12068,"created_at":"2012-07-26T09:56:33-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-26 13:56:33.730755
12198	new_post	139	{"id":12069,"created_at":"2012-07-26T10:15:44-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-07-26 14:15:44.993342
12199	new_user	Sam	{"unread_notifications":1}	2012-07-26 14:15:45.080131
12200	new_post	139	{"id":12070,"created_at":"2012-07-26T13:12:05-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":3}	2012-07-26 17:12:06.141906
12201	new_post	96	{"id":12071,"created_at":"2012-07-26T16:16:59-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":21}	2012-07-26 20:16:59.387468
12202	new_post	96	{"id":12072,"created_at":"2012-07-26T16:17:03-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":22}	2012-07-26 20:17:03.87988
12203	new_post	141	{"id":12073,"created_at":"2012-07-26T19:11:04-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-26 23:11:04.926778
12204	new_post	142	{"id":12074,"created_at":"2012-07-26T21:24:54-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-07-27 01:24:54.573384
12205	new_post	139	{"id":12075,"created_at":"2012-07-27T03:25:53-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":4}	2012-07-27 07:25:53.489074
12206	new_user	EvilTrout	{"unread_notifications":1}	2012-07-27 07:25:53.582448
12207	new_post	140	{"id":12076,"created_at":"2012-07-27T03:55:20-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-07-27 07:55:20.34504
12208	new_user	EvilTrout	{"unread_notifications":2}	2012-07-27 07:55:20.364698
12209	new_post	140	{"id":12077,"created_at":"2012-07-27T03:59:14-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":3}	2012-07-27 07:59:15.046419
12210	new_user	EvilTrout	{"unread_notifications":3}	2012-07-27 07:59:15.129493
12211	new_post	143	{"id":12078,"created_at":"2012-07-27T04:06:56-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-07-27 08:06:56.286084
12212	new_post	140	{"id":12079,"created_at":"2012-07-27T09:42:44-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":4}	2012-07-27 13:42:44.532385
12213	new_user	Sam	{"unread_notifications":1}	2012-07-27 13:42:44.962097
12214	new_post	143	{"id":12080,"created_at":"2012-07-27T11:03:18-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-07-27 15:03:18.80978
12215	new_user	Sam	{"unread_notifications":2}	2012-07-27 15:03:18.832376
12216	new_post	96	{"id":12081,"created_at":"2012-07-27T11:23:41-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":23}	2012-07-27 15:23:41.676289
12217	new_post	144	{"id":12082,"created_at":"2012-07-27T14:00:41-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-27 18:00:41.583329
12218	new_post	141	{"id":12083,"created_at":"2012-07-27T15:06:57-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-27 19:06:57.775563
12219	new_user	EvilTrout	{"unread_notifications":1}	2012-07-27 19:06:57.883926
12220	new_post	145	{"id":12084,"created_at":"2012-07-27T15:47:32-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-27 19:47:32.234415
12221	new_post	146	{"id":12085,"created_at":"2012-07-27T16:13:42-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":1}	2012-07-27 20:13:42.614301
12222	new_post	138	{"id":12086,"created_at":"2012-07-27T16:42:55-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-27 20:42:55.24254
12223	new_user	Sam	{"unread_notifications":3}	2012-07-27 20:42:55.29958
12224	new_post	146	{"id":12087,"created_at":"2012-07-27T16:54:42-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-27 20:54:42.773095
12225	new_user	Hanzo	{"unread_notifications":1}	2012-07-27 20:54:42.791941
12226	new_post	141	{"id":12088,"created_at":"2012-07-27T17:09:14-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-07-27 21:09:14.883908
12227	new_post	147	{"id":12089,"created_at":"2012-07-27T18:55:55-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-27 22:55:56.008196
12228	new_post	138	{"id":12090,"created_at":"2012-07-27T20:29:42-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":4}	2012-07-28 00:29:42.887657
12229	new_post	92	{"id":12091,"created_at":"2012-07-27T20:33:23-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":27}	2012-07-28 00:33:24.217312
12230	new_post	92	{"id":12092,"created_at":"2012-07-28T01:34:15-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":28}	2012-07-28 05:34:16.01908
11780	1	84	{"id":11769,"created_at":"2012-06-25T22:36:19-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-06-26 02:36:19.555306
11781	3	EvilTrout	{"unread_notifications":1}	2012-06-26 02:36:19.645073
11885	new_post	106	{"id":11846,"created_at":"2012-07-02T14:57:59-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-02 18:57:59.062739
11886	new_user	EvilTrout	{"unread_notifications":1}	2012-07-02 18:57:59.089864
12231	new_post	92	{"id":12093,"created_at":"2012-07-28T12:36:40-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":29}	2012-07-28 16:36:40.626087
12233	new_post	92	{"id":12095,"created_at":"2012-07-28T18:27:31-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":31}	2012-07-28 22:27:31.70437
12234	new_user	CodingHorror	{"unread_notifications":1}	2012-07-28 22:27:32.127083
11782	1	85	{"id":11770,"created_at":"2012-06-25T22:43:14-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-06-26 02:43:14.63941
11783	1	85	{"id":11771,"created_at":"2012-06-25T22:44:18-04:00","user":{"username":"EnfantTerrible","display_username":"Enfant Terrible","avatar_url":"/assets/avatars/4.jpg"},"post_number":2}	2012-06-26 02:44:18.200152
11887	new_post	102	{"id":11847,"created_at":"2012-07-02T14:59:36-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":4}	2012-07-02 18:59:36.560749
11888	new_post	107	{"id":11848,"created_at":"2012-07-02T15:00:16-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-02 19:00:16.278181
12232	new_post	92	{"id":12094,"created_at":"2012-07-28T12:46:56-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":30}	2012-07-28 16:46:57.207673
12235	new_post	138	{"id":12096,"created_at":"2012-07-29T08:28:07-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":5}	2012-07-29 12:28:07.963475
12236	new_user	CodingHorror	{"unread_notifications":1}	2012-07-29 12:28:08.110187
12237	new_post	145	{"id":12097,"created_at":"2012-07-29T08:30:09-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-07-29 12:30:09.569431
12238	new_user	CodingHorror	{"unread_notifications":2}	2012-07-29 12:30:09.637572
12239	new_post	145	{"id":12098,"created_at":"2012-07-29T21:06:34-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":3}	2012-07-30 01:06:34.916692
12240	new_user	CodingHorror	{"unread_notifications":3}	2012-07-30 01:06:35.037125
12241	new_post	138	{"id":12099,"created_at":"2012-07-30T00:20:52-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":6}	2012-07-30 04:20:52.885864
12242	new_user	Sam	{"unread_notifications":1}	2012-07-30 04:20:52.920824
12243	new_post	142	{"id":12100,"created_at":"2012-07-30T00:25:53-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-30 04:25:53.671317
12244	new_user	Sam	{"unread_notifications":2}	2012-07-30 04:25:53.717098
12245	new_post	142	{"id":12101,"created_at":"2012-07-30T00:28:24-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-30 04:28:24.43366
12246	new_post	96	{"id":12102,"created_at":"2012-07-30T11:29:37-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":24}	2012-07-30 15:29:37.89067
12247	new_post	145	{"id":12103,"created_at":"2012-07-30T13:10:56-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-07-30 17:10:56.869418
12248	new_user	Sam	{"unread_notifications":1}	2012-07-30 17:10:56.927917
12249	new_post	19	{"id":12104,"created_at":"2012-07-30T20:10:22-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":186}	2012-07-31 00:10:22.13376
12250	new_user	VinnyJH	{"unread_notifications":1}	2012-07-31 00:10:22.187489
12251	new_user	JackBatty	{"unread_notifications":1}	2012-07-31 00:10:22.194731
12252	new_user	Meatros	{"unread_notifications":1}	2012-07-31 00:10:22.199931
12253	new_user	VegasReno	{"unread_notifications":1}	2012-07-31 00:10:22.205107
12256	new_post	79	{"id":12106,"created_at":"2012-07-30T20:12:38-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":11}	2012-07-31 00:12:38.453966
12257	new_post	138	{"id":12107,"created_at":"2012-07-31T00:12:58-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":7}	2012-07-31 04:12:58.757285
12258	new_user	Sam	{"unread_notifications":1}	2012-07-31 04:12:58.803463
12259	new_post	96	{"id":12108,"created_at":"2012-07-31T12:40:08-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":25}	2012-07-31 16:40:09.042623
12260	new_post	92	{"id":12109,"created_at":"2012-07-31T13:34:37-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":32}	2012-07-31 17:34:37.994244
12261	new_post	148	{"id":12110,"created_at":"2012-07-31T13:36:14-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":1}	2012-07-31 17:36:14.514975
12262	new_post	149	{"id":12111,"created_at":"2012-07-31T13:42:12-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:12.963423
12263	new_post	150	{"id":12112,"created_at":"2012-07-31T13:42:41-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:41.924146
12264	new_post	151	{"id":12113,"created_at":"2012-07-31T13:42:41-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.00893
12265	new_post	152	{"id":12114,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.0421
12266	new_post	153	{"id":12115,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.101916
12267	new_post	154	{"id":12116,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.159796
12268	new_post	155	{"id":12117,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.193494
12269	new_post	156	{"id":12118,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.227249
12270	new_post	157	{"id":12119,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.317765
12271	new_post	158	{"id":12120,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.344714
12272	new_post	159	{"id":12121,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.402122
12273	new_post	160	{"id":12122,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.432734
11784	1	85	{"id":11772,"created_at":"2012-06-25T22:45:04-04:00","user":{"username":"TypoNegative","display_username":"Typo Negative","avatar_url":"/assets/avatars/2.jpg"},"post_number":3}	2012-06-26 02:45:04.378178
11785	1	85	{"id":11773,"created_at":"2012-06-25T22:45:42-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-06-26 02:45:42.354904
11786	3	EvilTrout	{"unread_notifications":2}	2012-06-26 02:45:42.382284
11889	new_post	106	{"id":11849,"created_at":"2012-07-02T15:16:32-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-07-02 19:16:32.135169
12254	new_post	19	{"id":12105,"created_at":"2012-07-30T20:10:40-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":187}	2012-07-31 00:10:40.878804
12255	new_user	CalMeacham	{"unread_notifications":1}	2012-07-31 00:10:40.91823
12274	new_post	161	{"id":12123,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.47923
12275	new_post	162	{"id":12124,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.509504
12276	new_post	163	{"id":12125,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.540115
12277	new_post	164	{"id":12126,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.611503
12278	new_post	165	{"id":12127,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.65017
12279	new_post	166	{"id":12128,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.6825
12280	new_post	167	{"id":12129,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.71056
12281	new_post	168	{"id":12130,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.761401
12282	new_post	169	{"id":12131,"created_at":"2012-07-31T13:42:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-31 17:42:42.791798
11787	new_post	83	{"id":11774,"created_at":"2012-06-25T22:49:04-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-06-26 02:49:04.509951
11890	new_post	108	{"id":11850,"created_at":"2012-07-02T17:49:15-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-02 21:49:15.666957
11893	new_post	92	{"id":11853,"created_at":"2012-07-02T19:08:10-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":5}	2012-07-02 23:08:10.569093
11895	new_post	91	{"id":11855,"created_at":"2012-07-02T19:21:48-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-02 23:21:48.210188
11896	new_post	92	{"id":11856,"created_at":"2012-07-02T23:38:33-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":6}	2012-07-03 03:38:33.8437
11897	new_user	CodingHorror	{"unread_notifications":1}	2012-07-03 03:38:33.87563
11898	new_post	92	{"id":11857,"created_at":"2012-07-02T23:39:40-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":7}	2012-07-03 03:39:40.154226
11899	new_post	91	{"id":11858,"created_at":"2012-07-03T02:00:15-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":4}	2012-07-03 06:00:15.26057
12283	new_post	148	{"id":12132,"created_at":"2012-07-31T14:52:46-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-07-31 18:52:46.271122
12284	new_user	Hanzo	{"unread_notifications":1}	2012-07-31 18:52:46.335047
12285	new_post	170	{"id":12133,"created_at":"2012-07-31T20:37:37-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-08-01 00:37:37.977822
12286	new_post	171	{"id":12134,"created_at":"2012-07-31T20:37:47-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-08-01 00:37:47.043007
12287	new_post	92	{"id":12135,"created_at":"2012-08-01T03:01:28-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":33}	2012-08-01 07:01:28.149559
12288	new_user	Hanzo	{"unread_notifications":2}	2012-08-01 07:01:28.19979
12289	new_post	92	{"id":12136,"created_at":"2012-08-01T03:05:25-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":34}	2012-08-01 07:05:25.115352
12290	new_post	96	{"id":12137,"created_at":"2012-08-01T11:27:09-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":26}	2012-08-01 15:27:09.427438
12291	new_post	172	{"id":12138,"created_at":"2012-08-01T16:39:20-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-08-01 20:39:21.143211
12292	new_post	19	{"id":12139,"created_at":"2012-08-01T16:40:04-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":186}	2012-08-01 20:40:05.002279
12293	new_user	VinnyJH	{"unread_notifications":1}	2012-08-01 20:40:05.080111
12294	new_post	92	{"id":12140,"created_at":"2012-08-01T18:14:36-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":35}	2012-08-01 22:14:37.072683
12295	new_post	148	{"id":12141,"created_at":"2012-08-01T18:26:08-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-08-01 22:26:08.72718
12296	new_user	Hanzo	{"unread_notifications":3}	2012-08-01 22:26:08.88073
12297	new_user	EvilTrout	{"unread_notifications":1}	2012-08-01 22:26:08.888985
12298	new_post	148	{"id":12142,"created_at":"2012-08-01T19:32:25-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":4}	2012-08-01 23:32:25.418399
12299	new_user	CodingHorror	{"unread_notifications":1}	2012-08-01 23:32:25.464816
12300	new_post	91	{"id":12143,"created_at":"2012-08-01T19:38:47-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":15}	2012-08-01 23:38:47.73945
12301	new_post	92	{"id":12144,"created_at":"2012-08-02T00:26:51-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":36}	2012-08-02 04:26:51.942513
12302	new_post	96	{"id":12145,"created_at":"2012-08-02T12:12:10-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":27}	2012-08-02 16:12:11.151315
12303	new_post	32	{"id":12146,"created_at":"2012-08-02T12:18:07-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":29}	2012-08-02 16:18:07.659831
12304	new_user	MojotheMonkey	{"unread_notifications":1}	2012-08-02 16:18:07.733519
12305	new_post	49	{"id":12147,"created_at":"2012-08-02T12:22:40-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":44}	2012-08-02 16:22:40.663587
12306	new_user	MaggietheOcelot	{"unread_notifications":1}	2012-08-02 16:22:40.686316
12307	new_post	49	{"id":12148,"created_at":"2012-08-02T12:33:19-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":45}	2012-08-02 16:33:19.985748
12308	new_post	173	{"id":12149,"created_at":"2012-08-02T18:48:03-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-08-02 22:48:03.452206
12309	new_post	174	{"id":12150,"created_at":"2012-08-02T18:51:25-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":1}	2012-08-02 22:51:25.595868
11788	new_post	84	{"id":11775,"created_at":"2012-06-25T22:49:24-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-06-26 02:49:24.292904
11789	new_post	86	{"id":11776,"created_at":"2012-06-25T22:51:20-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-06-26 02:51:20.586498
11891	new_post	109	{"id":11851,"created_at":"2012-07-02T18:07:29-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-07-02 22:07:29.511001
11892	new_post	104	{"id":11852,"created_at":"2012-07-02T18:37:22-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-07-02 22:37:22.622392
11894	new_post	110	{"id":11854,"created_at":"2012-07-02T19:15:46-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-07-02 23:15:46.091675
11790	new_post	81	{"id":11777,"created_at":"2012-06-25T22:52:49-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-06-26 02:52:49.689301
11791	new_user	EvilTrout	{"unread_notifications":1}	2012-06-26 02:52:49.702648
11900	new_post	96	{"id":11859,"created_at":"2012-07-03T09:42:24-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-07-03 13:42:24.748508
11792	new_post	21	{"id":11778,"created_at":"2012-06-26T01:42:09-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":44}	2012-06-26 05:42:09.645816
11793	new_post	21	{"id":11779,"created_at":"2012-06-26T01:42:30-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":45}	2012-06-26 05:42:30.679976
11901	new_post	98	{"id":11860,"created_at":"2012-07-03T10:05:42-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-07-03 14:05:42.82597
11902	new_post	95	{"id":11861,"created_at":"2012-07-03T10:36:34-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-07-03 14:36:34.689473
11794	new_post	83	{"id":11780,"created_at":"2012-06-26T10:06:32-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-06-26 14:06:32.296462
11798	new_post	19	{"id":11782,"created_at":"2012-06-26T11:10:03-04:00","user":{"username":"JackBatty","display_username":"Jack Batty","avatar_url":"/assets/avatars/7.jpg"},"post_number":187}	2012-06-26 15:10:03.237161
11799	new_user	CodingHorror	{"unread_notifications":1}	2012-06-26 15:10:03.326559
11800	new_post	19	{"id":11783,"created_at":"2012-06-26T11:10:40-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":188}	2012-06-26 15:10:40.943848
11801	new_user	JackBatty	{"unread_notifications":1}	2012-06-26 15:10:40.954515
11802	new_post	76	{"id":11784,"created_at":"2012-06-26T11:15:28-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":6}	2012-06-26 15:15:28.219172
11903	new_post	92	{"id":11862,"created_at":"2012-07-03T10:50:50-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":8}	2012-07-03 14:50:50.749738
11795	new_post	19	{"id":11781,"created_at":"2012-06-26T11:08:51-04:00","user":{"username":"CodingHorror","display_username":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":186}	2012-06-26 15:08:51.868143
11796	new_user	Meatros	{"unread_notifications":1}	2012-06-26 15:08:51.893978
11797	new_user	tullsterx	{"unread_notifications":1}	2012-06-26 15:08:51.901043
11803	new_post	83	{"id":11785,"created_at":"2012-06-27T03:11:43-04:00","user":{"username":"Sam","display_username":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":4}	2012-06-27 07:11:43.324732
11713	1	73	{"id":11712,"created_at":"2012-06-22T18:08:19-04:00","user":{"username":"EvilTrout","display_username":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-06-22 22:08:19.262197
11714	3	CodingHorror	{"unread_notifications":1}	2012-06-22 22:08:19.290809
11715	3	Sam	{"unread_notifications":1}	2012-06-22 22:08:19.296986
12310	new_post	97	{"id":12151,"created_at":"2012-08-02T21:41:36-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":5}	2012-08-03 01:41:36.086278
12311	new_post	97	{"id":12152,"created_at":"2012-08-03T00:37:36-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":6}	2012-08-03 04:37:36.531506
12312	new_user	EvilTrout	{"unread_notifications":1}	2012-08-03 04:37:36.556549
12313	new_post	142	{"id":12153,"created_at":"2012-08-03T02:27:31-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":4}	2012-08-03 06:27:31.620966
12314	new_post	142	{"id":12154,"created_at":"2012-08-03T04:10:41-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":5}	2012-08-03 08:10:42.034486
12315	new_post	92	{"id":12155,"created_at":"2012-08-03T07:13:42-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":37}	2012-08-03 11:13:42.299289
12316	new_post	96	{"id":12156,"created_at":"2012-08-03T11:09:11-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":28}	2012-08-03 15:09:11.942957
12317	new_post	19	{"id":12157,"created_at":"2012-08-03T17:21:58-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":186}	2012-08-03 21:21:58.089969
12318	new_user	MartinHyde	{"unread_notifications":1}	2012-08-03 21:21:58.117466
12319	new_user	Mangosteen	{"unread_notifications":1}	2012-08-03 21:21:58.126337
12320	new_user	rsat3acr	{"unread_notifications":1}	2012-08-03 21:21:58.13586
12321	new_post	19	{"id":12158,"created_at":"2012-08-03T17:23:01-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":187}	2012-08-03 21:23:01.640497
12323	new_post	31	{"id":12159,"created_at":"2012-08-03T17:35:08-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":31}	2012-08-03 21:35:08.435872
12324	new_post	31	{"id":12160,"created_at":"2012-08-03T17:36:10-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":32}	2012-08-03 21:36:11.016354
12325	new_user	CodingHorror	{"unread_notifications":1}	2012-08-03 21:36:11.044605
12335	new_post	175	{"id":12168,"created_at":"2012-08-05T20:41:14-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":6}	2012-08-06 00:41:14.381333
12337	new_post	176	{"id":12170,"created_at":"2012-08-05T21:46:39-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-08-06 01:46:39.26787
12338	new_user	Sam	{"unread_notifications":1}	2012-08-06 01:46:39.284597
12339	new_post	176	{"id":12171,"created_at":"2012-08-05T22:10:02-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":3}	2012-08-06 02:10:02.825888
12340	new_user	EvilTrout	{"unread_notifications":1}	2012-08-06 02:10:02.843658
12341	new_user	CodingHorror	{"unread_notifications":1}	2012-08-06 02:10:03.005822
12326	new_post	175	{"id":12161,"created_at":"2012-08-04T03:23:47-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":1}	2012-08-04 07:23:47.2287
12327	new_post	175	{"id":12162,"created_at":"2012-08-04T03:29:42-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-08-04 07:29:42.272093
12328	new_post	175	{"id":12163,"created_at":"2012-08-04T03:38:06-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-08-04 07:38:06.453701
12329	new_post	175	{"id":12164,"created_at":"2012-08-04T04:00:17-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-08-04 08:00:17.933624
12330	new_post	175	{"id":12165,"created_at":"2012-08-04T04:34:28-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-08-04 08:34:28.22429
12331	new_post	175	{"id":12166,"created_at":"2012-08-04T22:58:45-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":5}	2012-08-05 02:58:45.336933
12332	new_user	CodingHorror	{"unread_notifications":1}	2012-08-05 02:58:45.359492
12333	new_post	92	{"id":12167,"created_at":"2012-08-04T23:02:29-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":38}	2012-08-05 03:02:29.585194
12334	new_user	Sam	{"unread_notifications":1}	2012-08-05 03:02:29.600915
12336	new_post	176	{"id":12169,"created_at":"2012-08-05T21:34:30-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-08-06 01:34:30.892436
12342	new_post	92	{"id":12172,"created_at":"2012-08-05T22:11:23-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":39}	2012-08-06 02:11:23.655456
12343	new_post	92	{"id":12173,"created_at":"2012-08-05T22:22:22-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":40}	2012-08-06 02:22:22.80063
12344	new_post	142	{"id":12174,"created_at":"2012-08-06T01:08:09-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":6}	2012-08-06 05:08:09.802692
12345	new_post	177	{"id":12175,"created_at":"2012-08-06T01:11:22-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-08-06 05:11:22.651943
12346	new_post	96	{"id":12176,"created_at":"2012-08-06T08:31:22-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":29}	2012-08-06 12:31:22.871548
12347	new_user	EvilTrout	{"unread_notifications":2}	2012-08-06 12:31:22.90437
12348	new_post	92	{"id":12177,"created_at":"2012-08-06T08:33:19-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":41}	2012-08-06 12:33:19.317071
12349	new_post	92	{"id":12178,"created_at":"2012-08-06T08:35:55-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":42}	2012-08-06 12:35:55.099297
12350	new_post	177	{"id":12179,"created_at":"2012-08-06T11:12:49-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-08-06 15:12:49.719123
12351	new_user	Sam	{"unread_notifications":1}	2012-08-06 15:12:49.745995
12352	new_post	177	{"id":12180,"created_at":"2012-08-06T17:43:44-04:00","user":{"username":"shawn.a.holmes","name":"Shawn A.holmes","avatar_url":"http://www.gravar.com/avatar/f8ba22314a43c9e9d462b5bca36dd29b.png?s=128&r=pg&default=http%3A%2F%2Frobohash.org%2Ff8ba22314a43c9e9d462b5bca36dd29b.png%3Fsize%3D128x128"},"post_number":3}	2012-08-06 21:43:44.441344
12353	new_user	Sam	{"unread_notifications":1}	2012-08-06 21:43:44.46698
12354	new_post	178	{"id":12181,"created_at":"2012-08-06T17:47:58-04:00","user":{"username":"shawn.a.holmes","name":"Shawn A.holmes","avatar_url":"http://www.gravar.com/avatar/f8ba22314a43c9e9d462b5bca36dd29b.png?s=128&r=pg&default=http%3A%2F%2Frobohash.org%2Ff8ba22314a43c9e9d462b5bca36dd29b.png%3Fsize%3D128x128"},"post_number":1}	2012-08-06 21:47:58.564899
12355	new_post	19	{"id":12182,"created_at":"2012-08-06T19:31:30-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":186}	2012-08-06 23:31:30.716509
12356	new_user	ILoveMe,VolI	{"unread_notifications":1}	2012-08-06 23:31:30.787886
12357	new_user	BrainGlutton	{"unread_notifications":1}	2012-08-06 23:31:30.797652
12358	new_user	CaptKirk	{"unread_notifications":1}	2012-08-06 23:31:30.806731
12359	new_post	177	{"id":12183,"created_at":"2012-08-06T20:20:00-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":4}	2012-08-07 00:20:00.492042
12360	new_user	shawn.a.holmes	{"unread_notifications":1}	2012-08-07 00:20:00.514271
12361	new_user	Hanzo	{"unread_notifications":1}	2012-08-07 00:20:00.523476
12362	new_post	177	{"id":12184,"created_at":"2012-08-06T20:20:36-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":5}	2012-08-07 00:20:36.28445
12363	new_user	EvilTrout	{"unread_notifications":1}	2012-08-07 00:20:36.353066
12364	new_post	178	{"id":12185,"created_at":"2012-08-06T23:08:26-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-08-07 03:08:26.686939
12365	new_user	shawn.a.holmes	{"unread_notifications":2}	2012-08-07 03:08:26.746725
12366	new_post	177	{"id":12186,"created_at":"2012-08-07T01:09:31-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":6}	2012-08-07 05:09:31.375352
12367	new_post	176	{"id":12187,"created_at":"2012-08-07T01:34:58-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-08-07 05:34:58.28691
12368	new_post	96	{"id":12188,"created_at":"2012-08-07T03:33:50-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":29}	2012-08-07 07:33:50.616503
12369	new_post	92	{"id":12189,"created_at":"2012-08-07T03:42:45-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":43}	2012-08-07 07:42:45.474647
12370	new_post	92	{"id":12190,"created_at":"2012-08-07T03:45:15-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":44}	2012-08-07 07:45:15.046362
12371	new_user	Hanzo	{"unread_notifications":2}	2012-08-07 07:45:15.07388
12372	new_post	176	{"id":12191,"created_at":"2012-08-07T04:26:16-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":5}	2012-08-07 08:26:16.944418
12373	new_user	CodingHorror	{"unread_notifications":1}	2012-08-07 08:26:16.973877
12374	new_post	111	{"id":12192,"created_at":"2012-08-07T04:29:31-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":3}	2012-08-07 08:29:31.550791
12375	new_user	Hanzo	{"unread_notifications":3}	2012-08-07 08:29:31.566396
12376	new_post	92	{"id":12193,"created_at":"2012-08-07T04:30:31-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":45}	2012-08-07 08:30:31.439983
12377	new_post	92	{"id":12194,"created_at":"2012-08-07T04:43:49-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":46}	2012-08-07 08:43:49.222986
12378	new_post	177	{"id":12195,"created_at":"2012-08-07T10:27:44-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":7}	2012-08-07 14:27:44.924379
12379	new_user	Sam	{"unread_notifications":1}	2012-08-07 14:27:44.94029
12380	new_post	96	{"id":12196,"created_at":"2012-08-07T11:49:38-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":30}	2012-08-07 15:49:38.090309
12381	new_post	176	{"id":12197,"created_at":"2012-08-07T15:24:48-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":6}	2012-08-07 19:24:48.497685
12382	new_user	Sam	{"unread_notifications":2}	2012-08-07 19:24:48.529355
12383	new_post	177	{"id":12198,"created_at":"2012-08-07T18:52:40-04:00","user":{"username":"shawn.a.holmes","name":"Shawn A.holmes","avatar_url":"http://www.gravatar.com/avatar/f8ba22314a43c9e9d462b5bca36dd29b.png?s=128&r=pg&default=http%3A%2F%2Frobohash.org%2Ff8ba22314a43c9e9d462b5bca36dd29b.png%3Fsize%3D128x128"},"post_number":8}	2012-08-07 22:52:40.27805
12384	new_user	Sam	{"unread_notifications":2}	2012-08-07 22:52:40.350424
12385	new_user	Hanzo	{"unread_notifications":1}	2012-08-07 22:52:40.359943
12386	new_post	178	{"id":12199,"created_at":"2012-08-07T18:53:36-04:00","user":{"username":"shawn.a.holmes","name":"Shawn A.holmes","avatar_url":"http://www.gravatar.com/avatar/f8ba22314a43c9e9d462b5bca36dd29b.png?s=128&r=pg&default=http%3A%2F%2Frobohash.org%2Ff8ba22314a43c9e9d462b5bca36dd29b.png%3Fsize%3D128x128"},"post_number":3}	2012-08-07 22:53:36.902935
12387	new_user	Sam	{"unread_notifications":3}	2012-08-07 22:53:36.9182
12388	new_post	178	{"id":12200,"created_at":"2012-08-07T18:55:05-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":4}	2012-08-07 22:55:05.465816
12389	new_user	shawn.a.holmes	{"unread_notifications":1}	2012-08-07 22:55:05.47797
12390	new_post	178	{"id":12201,"created_at":"2012-08-07T18:55:54-04:00","user":{"username":"shawn.a.holmes","name":"Shawn A.holmes","avatar_url":"http://www.gravatar.com/avatar/f8ba22314a43c9e9d462b5bca36dd29b.png?s=128&r=pg&default=http%3A%2F%2Frobohash.org%2Ff8ba22314a43c9e9d462b5bca36dd29b.png%3Fsize%3D128x128"},"post_number":5}	2012-08-07 22:55:54.352555
12391	new_user	CodingHorror	{"unread_notifications":1}	2012-08-07 22:55:54.376197
12392	new_post	177	{"id":12202,"created_at":"2012-08-07T21:17:11-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":9}	2012-08-08 01:17:11.255902
12393	new_user	shawn.a.holmes	{"unread_notifications":1}	2012-08-08 01:17:11.27614
12394	new_post	176	{"id":12203,"created_at":"2012-08-07T22:10:34-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":7}	2012-08-08 02:10:34.69937
12395	new_user	Sam	{"unread_notifications":1}	2012-08-08 02:10:34.711529
12396	new_post	176	{"id":12204,"created_at":"2012-08-07T22:27:49-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":8}	2012-08-08 02:27:49.109681
12397	new_user	EvilTrout	{"unread_notifications":1}	2012-08-08 02:27:49.12557
12398	new_post	176	{"id":12205,"created_at":"2012-08-07T23:00:03-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":9}	2012-08-08 03:00:03.256896
12399	new_user	Sam	{"unread_notifications":1}	2012-08-08 03:00:03.269574
12400	new_post	179	{"id":12206,"created_at":"2012-08-08T00:54:51-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-08-08 04:54:51.203582
12401	new_post	180	{"id":12207,"created_at":"2012-08-08T01:24:04-04:00","user":{"username":"shawn.a.holmes","name":"Shawn A.holmes","avatar_url":"http://www.gravatar.com/avatar/f8ba22314a43c9e9d462b5bca36dd29b.png?s=128&r=pg&default=http%3A%2F%2Frobohash.org%2Ff8ba22314a43c9e9d462b5bca36dd29b.png%3Fsize%3D128x128"},"post_number":1}	2012-08-08 05:24:04.222255
12402	new_post	181	{"id":12208,"created_at":"2012-08-08T01:32:22-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-08-08 05:32:22.66511
12403	new_post	180	{"id":12209,"created_at":"2012-08-08T02:03:01-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-08-08 06:03:01.951902
12404	new_user	shawn.a.holmes	{"unread_notifications":1}	2012-08-08 06:03:01.970285
12405	new_post	180	{"id":12210,"created_at":"2012-08-08T02:03:25-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":3}	2012-08-08 06:03:25.121013
12406	new_user	shawn.a.holmes	{"unread_notifications":2}	2012-08-08 06:03:25.136619
12407	new_post	177	{"id":12211,"created_at":"2012-08-08T04:43:05-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":10}	2012-08-08 08:43:06.056301
12408	new_user	Hanzo	{"unread_notifications":1}	2012-08-08 08:43:06.08629
12409	new_user	EvilTrout	{"unread_notifications":1}	2012-08-08 08:43:06.095482
12410	new_user	CodingHorror	{"unread_notifications":1}	2012-08-08 08:43:06.104735
12411	new_post	96	{"id":12212,"created_at":"2012-08-08T04:46:36-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":31}	2012-08-08 08:46:36.384636
12412	new_post	182	{"id":12213,"created_at":"2012-08-08T05:15:57-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-08-08 09:15:57.667652
12413	new_post	181	{"id":12214,"created_at":"2012-08-08T08:37:21-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-08-08 12:37:21.702494
12414	new_user	Sam	{"unread_notifications":1}	2012-08-08 12:37:21.729507
12415	new_post	182	{"id":12215,"created_at":"2012-08-08T09:37:51-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-08-08 13:37:51.742553
12416	new_user	Sam	{"unread_notifications":2}	2012-08-08 13:37:51.765663
12417	new_post	179	{"id":12216,"created_at":"2012-08-08T09:43:46-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-08-08 13:43:46.034809
12419	new_post	183	{"id":12217,"created_at":"2012-08-08T09:48:54-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-08-08 13:48:54.059157
12420	new_post	177	{"id":12218,"created_at":"2012-08-08T09:49:49-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":11}	2012-08-08 13:49:49.404007
12421	new_post	96	{"id":12219,"created_at":"2012-08-08T10:28:53-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":32}	2012-08-08 14:28:53.198931
12422	new_post	177	{"id":12220,"created_at":"2012-08-08T20:04:02-04:00","user":{"username":"shawn.a.holmes","name":"Shawn A.holmes","avatar_url":"http://www.gravatar.com/avatar/f8ba22314a43c9e9d462b5bca36dd29b.png?s=128&r=pg&default=http%3A%2F%2Frobohash.org%2Ff8ba22314a43c9e9d462b5bca36dd29b.png%3Fsize%3D128x128"},"post_number":12}	2012-08-09 00:04:02.128334
12423	new_user	Sam	{"unread_notifications":1}	2012-08-09 00:04:02.159518
12424	new_post	180	{"id":12221,"created_at":"2012-08-08T20:12:06-04:00","user":{"username":"shawn.a.holmes","name":"Shawn A.holmes","avatar_url":"http://www.gravatar.com/avatar/f8ba22314a43c9e9d462b5bca36dd29b.png?s=128&r=pg&default=http%3A%2F%2Frobohash.org%2Ff8ba22314a43c9e9d462b5bca36dd29b.png%3Fsize%3D128x128"},"post_number":4}	2012-08-09 00:12:06.933307
12425	new_user	Sam	{"unread_notifications":2}	2012-08-09 00:12:06.951132
12426	new_post	180	{"id":12222,"created_at":"2012-08-08T20:30:19-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":5}	2012-08-09 00:30:19.458509
12427	new_user	shawn.a.holmes	{"unread_notifications":1}	2012-08-09 00:30:19.488685
12428	new_post	177	{"id":12223,"created_at":"2012-08-08T20:32:00-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":13}	2012-08-09 00:32:00.754409
12429	new_user	shawn.a.holmes	{"unread_notifications":2}	2012-08-09 00:32:00.781852
12430	new_post	180	{"id":12224,"created_at":"2012-08-08T21:21:12-04:00","user":{"username":"shawn.a.holmes","name":"Shawn A.holmes","avatar_url":"http://www.gravatar.com/avatar/f8ba22314a43c9e9d462b5bca36dd29b.png?s=128&r=pg&default=http%3A%2F%2Frobohash.org%2Ff8ba22314a43c9e9d462b5bca36dd29b.png%3Fsize%3D128x128"},"post_number":6}	2012-08-09 01:21:12.961932
12431	new_user	CodingHorror	{"unread_notifications":1}	2012-08-09 01:21:12.980623
12432	new_post	182	{"id":12225,"created_at":"2012-08-08T21:21:44-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":3}	2012-08-09 01:21:44.901527
12433	new_post	177	{"id":12226,"created_at":"2012-08-08T21:22:59-04:00","user":{"username":"shawn.a.holmes","name":"Shawn A.holmes","avatar_url":"http://www.gravatar.com/avatar/f8ba22314a43c9e9d462b5bca36dd29b.png?s=128&r=pg&default=http%3A%2F%2Frobohash.org%2Ff8ba22314a43c9e9d462b5bca36dd29b.png%3Fsize%3D128x128"},"post_number":14}	2012-08-09 01:22:59.420997
12434	new_user	CodingHorror	{"unread_notifications":2}	2012-08-09 01:22:59.439133
12435	new_post	183	{"id":12227,"created_at":"2012-08-08T21:26:38-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-08-09 01:26:38.141773
12436	new_user	EvilTrout	{"unread_notifications":1}	2012-08-09 01:26:38.159689
12437	new_user	CodingHorror	{"unread_notifications":3}	2012-08-09 01:26:38.169132
12438	new_post	177	{"id":12228,"created_at":"2012-08-08T21:27:45-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":15}	2012-08-09 01:27:45.022926
12439	new_user	shawn.a.holmes	{"unread_notifications":1}	2012-08-09 01:27:45.048676
12440	new_post	184	{"id":12229,"created_at":"2012-08-08T21:30:56-04:00","user":{"username":"shawn.a.holmes","name":"Shawn A.holmes","avatar_url":"http://www.gravatar.com/avatar/f8ba22314a43c9e9d462b5bca36dd29b.png?s=128&r=pg&default=http%3A%2F%2Frobohash.org%2Ff8ba22314a43c9e9d462b5bca36dd29b.png%3Fsize%3D128x128"},"post_number":1}	2012-08-09 01:30:56.977173
12441	new_post	184	{"id":12230,"created_at":"2012-08-08T21:35:27-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-08-09 01:35:27.155979
12442	new_user	shawn.a.holmes	{"unread_notifications":1}	2012-08-09 01:35:27.171562
12443	new_post	177	{"id":12231,"created_at":"2012-08-08T21:38:03-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":16}	2012-08-09 01:38:03.463915
12444	new_user	Sam	{"unread_notifications":1}	2012-08-09 01:38:03.479472
12445	new_post	185	{"id":12232,"created_at":"2012-08-08T21:40:54-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":1}	2012-08-09 01:40:54.103471
12446	new_post	177	{"id":12233,"created_at":"2012-08-08T21:41:31-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":17}	2012-08-09 01:41:31.312022
12447	new_user	Hanzo	{"unread_notifications":1}	2012-08-09 01:41:31.329738
12448	new_post	177	{"id":12234,"created_at":"2012-08-08T21:42:21-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":18}	2012-08-09 01:42:21.176388
12449	new_user	Sam	{"unread_notifications":1}	2012-08-09 01:42:21.191683
12450	new_post	91	{"id":12235,"created_at":"2012-08-09T00:07:46-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":16}	2012-08-09 04:07:46.372495
12451	new_post	185	{"id":12237,"created_at":"2012-08-09T09:36:58-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":2}	2012-08-09 13:36:58.316435
12452	new_user	Sam	{"unread_notifications":1}	2012-08-09 13:36:58.345168
12453	new_post	97	{"id":12242,"created_at":"2012-08-09T11:51:25-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":7}	2012-08-09 15:51:25.147131
12454	new_post	97	{"id":12243,"created_at":"2012-08-09T11:53:13-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":7}	2012-08-09 15:53:13.525376
12455	new_post	12	{"id":12244,"created_at":"2012-08-09T13:14:57-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":54}	2012-08-09 17:14:57.318098
12456	new_post	180	{"id":12245,"created_at":"2012-08-09T14:22:26-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":7}	2012-08-09 18:22:26.887498
12457	new_user	shawn.a.holmes	{"unread_notifications":1}	2012-08-09 18:22:26.916075
12458	new_post	183	{"id":12246,"created_at":"2012-08-09T14:24:03-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":3}	2012-08-09 18:24:03.046981
12459	new_post	17	{"id":12247,"created_at":"2012-08-09T14:28:49-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":233}	2012-08-09 18:28:49.082547
12460	new_post	12	{"id":12248,"created_at":"2012-08-09T14:50:17-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":55}	2012-08-09 18:50:17.825366
12461	new_user	gms453	{"unread_notifications":1}	2012-08-09 18:50:17.853062
12462	new_user	Marley23	{"unread_notifications":1}	2012-08-09 18:50:17.860545
12463	new_user	rachelellogram	{"unread_notifications":1}	2012-08-09 18:50:17.867786
12464	new_post	12	{"id":12249,"created_at":"2012-08-09T14:50:34-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":56}	2012-08-09 18:50:34.3692
12466	new_post	12	{"id":12250,"created_at":"2012-08-09T15:07:30-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":57}	2012-08-09 19:07:30.585409
12467	new_user	BarkisisWillin'	{"unread_notifications":2}	2012-08-09 19:07:30.597994
12468	new_post	185	{"id":12251,"created_at":"2012-08-09T15:47:17-04:00","user":{"username":"Hanzo","name":"Hanzo","avatar_url":"/assets/cool_avatars/hanzo.png"},"post_number":3}	2012-08-09 19:47:17.272989
12469	new_post	185	{"id":12252,"created_at":"2012-08-09T20:24:47-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":4}	2012-08-10 00:24:47.674673
12470	new_user	Hanzo	{"unread_notifications":1}	2012-08-10 00:24:47.704014
12471	new_post	185	{"id":12253,"created_at":"2012-08-09T22:14:37-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":5}	2012-08-10 02:14:37.740176
12472	new_post	186	{"id":12254,"created_at":"2012-08-10T09:35:23-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-08-10 13:35:23.543952
12473	new_post	187	{"id":12255,"created_at":"2012-08-10T09:43:37-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-08-10 13:43:37.424423
12474	new_post	188	{"id":12256,"created_at":"2012-08-10T09:52:16-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-08-10 13:52:16.958892
12475	new_post	92	{"id":12257,"created_at":"2012-08-10T15:10:34-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":47}	2012-08-10 19:10:34.19533
12476	new_post	188	{"id":12258,"created_at":"2012-08-10T19:58:47-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-08-10 23:58:47.487518
12477	new_user	EvilTrout	{"unread_notifications":1}	2012-08-10 23:58:47.520079
12478	new_post	188	{"id":12259,"created_at":"2012-08-10T20:34:05-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-08-11 00:34:05.571313
12479	new_user	Sam	{"unread_notifications":1}	2012-08-11 00:34:05.604332
12480	new_post	188	{"id":12260,"created_at":"2012-08-11T02:19:26-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":4}	2012-08-11 06:19:26.850743
12481	new_user	EvilTrout	{"unread_notifications":1}	2012-08-11 06:19:26.86674
12482	new_post	188	{"id":12261,"created_at":"2012-08-11T08:42:22-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":5}	2012-08-11 12:42:22.516594
12483	new_post	188	{"id":12262,"created_at":"2012-08-11T11:28:36-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":6}	2012-08-11 15:28:36.203619
12484	new_post	188	{"id":12263,"created_at":"2012-08-11T19:54:32-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":7}	2012-08-11 23:54:32.673287
12485	new_post	188	{"id":12264,"created_at":"2012-08-11T23:31:17-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":8}	2012-08-12 03:31:17.277945
12486	new_post	189	{"id":12265,"created_at":"2012-08-12T17:41:42-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-08-12 21:41:42.972802
12487	new_user	Sam	{"unread_notifications":1}	2012-08-12 21:41:43.233784
12488	new_post	189	{"id":12266,"created_at":"2012-08-12T21:49:16-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":2}	2012-08-13 01:49:16.390443
12489	new_user	EvilTrout	{"unread_notifications":1}	2012-08-13 01:49:16.407705
12490	new_post	189	{"id":12267,"created_at":"2012-08-12T23:56:20-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-08-13 03:56:20.493778
12491	new_user	Sam	{"unread_notifications":1}	2012-08-13 03:56:20.510662
12492	new_post	96	{"id":12268,"created_at":"2012-08-13T11:10:31-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":33}	2012-08-13 15:10:31.088286
12493	new_post	190	{"id":12269,"created_at":"2012-08-13T15:30:38-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-08-13 19:30:38.753993
12494	new_post	96	{"id":12270,"created_at":"2012-08-14T01:02:29-04:00","user":{"username":"Sam","name":"Sam","avatar_url":"/assets/cool_avatars/sam.png"},"post_number":36}	2012-08-14 05:02:29.836072
12495	new_post	96	{"id":12271,"created_at":"2012-08-14T12:15:16-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":37}	2012-08-14 16:15:17.044299
12496	new_post	190	{"id":12272,"created_at":"2012-08-14T15:09:34-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":2}	2012-08-14 19:09:34.224956
12497	new_user	EvilTrout	{"unread_notifications":1}	2012-08-14 19:09:34.254589
12498	new_post	175	{"id":12273,"created_at":"2012-08-14T15:20:39-04:00","user":{"username":"CodingHorror","name":"Coding Horror","avatar_url":"/assets/cool_avatars/coding_horror.png"},"post_number":8}	2012-08-14 19:20:39.513653
12499	new_user	Sam	{"unread_notifications":1}	2012-08-14 19:20:39.529933
12500	new_post	191	{"id":12274,"created_at":"2012-08-14T16:30:23-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":1}	2012-08-14 20:30:23.189625
12501	new_post	190	{"id":12275,"created_at":"2012-08-14T18:43:12-04:00","user":{"username":"EvilTrout","name":"Evil Trout","avatar_url":"/assets/cool_avatars/evil_trout.jpg"},"post_number":3}	2012-08-14 22:43:12.319857
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY notifications (id, notification_type, user_id, data, read, created_at, updated_at, topic_id, post_number, post_action_id) FROM stdin;
\.


--
-- Data for Name: onebox_renders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY onebox_renders (id, url, cooked, expires_at, created_at, updated_at, preview) FROM stdin;
\.


--
-- Data for Name: post_action_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_action_types (name_key, is_flag, icon, created_at, updated_at, id) FROM stdin;
bookmark	f	\N	2013-01-07 21:57:50.153539	2013-01-07 21:57:50.153539	1
like	f	heart	2013-01-07 21:57:50.164792	2013-01-07 21:57:50.164792	2
off_topic	t	\N	2013-01-07 21:57:50.168544	2013-01-07 21:57:50.168544	3
offensive	t	\N	2013-01-07 21:57:50.172436	2013-01-07 21:57:50.172436	4
vote	f	\N	2013-01-07 21:57:50.177984	2013-01-07 21:57:50.177984	5
\.


--
-- Data for Name: post_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_actions (id, post_id, user_id, post_action_type_id, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: post_onebox_renders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_onebox_renders (post_id, onebox_render_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: post_replies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_replies (post_id, reply_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: post_timings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY post_timings (topic_id, post_number, user_id, msecs) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY posts (id, user_id, topic_id, post_number, raw, cooked, created_at, updated_at, reply_to_post_number, cached_version, reply_count, quote_count, reply_below_post_number, deleted_at, off_topic_count, offensive_count, like_count, incoming_link_count, bookmark_count, avg_time, score, reads, post_type, vote_count, sort_order, last_editor_id) FROM stdin;
9	2	9	1	Hi there!\n\nWelcome to Discourse. \n\nEnjoy your stay. Let us know if you need anything.\n	<p>Hi there!</p>\n\n<p>Welcome to Discourse. </p>\n\n<p>Enjoy your stay. Let us know if you need anything.  </p>	2013-01-07 21:56:54.616967	2013-01-07 21:56:54.616967	\N	1	0	0	\N	\N	0	0	0	0	0	\N	\N	0	1	0	1	2
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY schema_migrations (version) FROM stdin;
20120311163914
20120311164326
20120311170118
20120311201341
20120311210245
20120416201606
20120420183447
20120423140906
20120423142820
20120423151548
20120425145456
20120427150624
20120427151452
20120427154330
20120427172031
20120502183240
20120502192121
20120503205521
20120507144132
20120507144222
20120514144549
20120514173920
20120514204934
20120517200130
20120518200115
20120519182212
20120523180723
20120523184307
20120523201329
20120525194845
20120529175956
20120529202707
20120530150726
20120530160745
20120530200724
20120530212912
20120614190726
20120614202024
20120615180517
20120618152946
20120618212349
20120618214856
20120619150807
20120619153349
20120619172714
20120621155351
20120621190310
20120622200242
20120625145714
20120625162318
20120625174544
20120625195326
20120629143908
20120629150253
20120629151243
20120629182637
20120702211427
20120703184734
20120703201312
20120703203623
20120703210004
20120704160659
20120704201743
20120705181724
20120708210305
20120712150500
20120712151934
20120713201324
20120716020835
20120716173544
20120718044955
20120719004636
20120720013733
20120720044246
20120720162422
20120723051512
20120724234502
20120724234711
20120725183347
20120726201830
20120726235129
20120727005556
20120727150428
20120727213543
20120802151210
20120806030641
20120806062617
20120803191426
20120807223020
20120809020415
20120809030647
20120809053414
20120809154750
20120809174649
20120809175110
20120809201855
20120810064839
20120813201426
20120812235417
20120813004347
20120813042912
20120815004411
20120815180106
20120815204733
20120816050526
20120816205537
20120816205538
20120820191804
20120821191616
20120823205956
20120824171908
20120828204209
20120828204624
20120830182736
20120910171504
20120918152319
20120918205931
20120919152846
20120921055428
20120921155050
20120921162512
20120921163606
20120924182031
20120924182000
20120925171620
20120925190802
20120928170023
20121009161116
20121011155904
20121017162924
20121018103721
20121018182709
20121018133039
20121106015500
20121108193516
20121109164630
20121113200844
20121113200845
20121115172544
20121116212424
20121119190529
20121119200843
20121122033316
20121121202035
20121121205215
20121123054127
20121123063630
20121129160035
20121129184948
20121130191818
20121130010400
20121202225421
20121203181719
20121204183855
20121204193747
20121205162143
20121207000741
20121211233131
20121216230719
20121218205642
20121224072204
20121224095139
20121224100650
20121228192219
20130107165207
20130108195847
\.


--
-- Data for Name: site_customizations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY site_customizations (id, name, stylesheet, header, "position", user_id, enabled, key, created_at, updated_at, override_default_style, stylesheet_baked) FROM stdin;
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY site_settings (id, name, data_type, value, created_at, updated_at) FROM stdin;
1	system_username	1	admin	2013-01-07 21:57:34.992013	2013-01-07 21:57:34.992013
2	title	1	Try Discourse	2013-01-07 21:58:44.645732	2013-01-07 21:58:44.645732
\.


--
-- Data for Name: topic_allowed_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_allowed_users (id, user_id, topic_id, created_at, updated_at) FROM stdin;
2	2	9	2013-01-07 21:56:54.295319	2013-01-07 21:56:54.295319
\.


--
-- Data for Name: topic_invites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_invites (id, topic_id, invite_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: topic_link_clicks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_link_clicks (id, topic_link_id, user_id, ip, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: topic_links; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_links (id, topic_id, post_id, user_id, url, domain, internal, link_topic_id, created_at, updated_at, reflection, clicks, link_post_id) FROM stdin;
\.


--
-- Data for Name: topic_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topic_users (user_id, topic_id, starred, posted, last_read_post_number, seen_post_count, starred_at, muted_at, last_visited_at, first_visited_at, notifications, notifications_changed_at, notifications_reason_id) FROM stdin;
2	9	f	t	1	1	\N	\N	2013-01-07 21:56:54	2013-01-07 21:56:54	1	2013-01-07 21:56:54	1
\.


--
-- Data for Name: topics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY topics (id, title, last_posted_at, created_at, updated_at, views, posts_count, user_id, last_post_user_id, reply_count, featured_user1_id, featured_user2_id, featured_user3_id, avg_time, deleted_at, highest_post_number, image_url, off_topic_count, offensive_count, like_count, incoming_link_count, bookmark_count, star_count, category_id, visible, moderator_posts_count, closed, pinned, archived, bumped_at, sub_tag, has_best_of, meta_data, vote_count, archetype, featured_user4_id) FROM stdin;
9	Welcome to Discourse!	2013-01-07 21:56:54.616967	2013-01-07 21:56:54.281529	2013-01-07 21:56:54.81107	0	1	2	2	0	\N	\N	\N	\N	\N	1	\N	0	0	0	0	0	0	\N	t	0	f	f	f	2013-01-07 21:56:54.280898	\N	f	\N	0	private_message	\N
\.


--
-- Data for Name: trust_levels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY trust_levels (id, name_key, created_at, updated_at) FROM stdin;
1	none	2013-01-07 21:57:50.20362	2013-01-07 21:57:50.20362
2	basic	2013-01-07 21:57:50.209007	2013-01-07 21:57:50.209007
\.


--
-- Data for Name: twitter_user_infos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY twitter_user_infos (id, user_id, screen_name, twitter_user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: uploads; Type: TABLE DATA; Schema: public; Owner: -
--

COPY uploads (id, user_id, topic_id, original_filename, filesize, width, height, url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_actions (id, action_type, user_id, target_topic_id, target_post_id, target_user_id, acting_user_id, created_at, updated_at) FROM stdin;
23	12	2	9	-1	\N	2	2013-01-07 21:56:54.281529	2013-01-07 21:56:54.436811
\.


--
-- Data for Name: user_open_ids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_open_ids (id, user_id, email, url, created_at, updated_at, active) FROM stdin;
\.


--
-- Data for Name: user_visits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY user_visits (id, user_id, visited_at) FROM stdin;
2	2	2013-01-07
3	2	2013-01-14
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY users (id, username, created_at, updated_at, name, bio_raw, seen_notification_id, last_posted_at, email, password_hash, salt, active, username_lower, auth_token, last_seen_at, website, admin, moderator, last_emailed_at, email_digests, trust_level_id, bio_cooked, email_private_messages, email_direct, approved, approved_by_id, approved_at, topics_entered, posts_read_count, digest_after_days, previous_visit_at) FROM stdin;
2	admin	2013-01-07 21:55:41.905352	2013-01-14 20:06:40.981705	Admin	\N	0	2013-01-07 21:56:54.616967	neil.lalonde+admin@gmail.com	d709cbd1fc4b9a3fe0052606fc84ff3c32af55a94442e5df26f10697c5e03f1c	1cdd5f082f3c576787addad76b65fb21	t	admin	87610f67099c5a6d71c6a7b1551389a7	2013-01-14 20:06:40	\N	t	f	2013-01-07 21:56:05.123178	t	1	\N	t	t	f	\N	\N	0	0	7	2013-01-07 21:58:48
\.


--
-- Data for Name: versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY versions (id, versioned_id, versioned_type, user_id, user_type, user_name, modifications, number, reverted_from, tag, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: views; Type: TABLE DATA; Schema: public; Owner: -
--

COPY views (parent_id, parent_type, ip, viewed_at, user_id) FROM stdin;
\.


--
-- Name: actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_actions
    ADD CONSTRAINT actions_pkey PRIMARY KEY (id);


--
-- Name: categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: category_featured_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY category_featured_users
    ADD CONSTRAINT category_featured_users_pkey PRIMARY KEY (id);


--
-- Name: draft_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY draft_sequences
    ADD CONSTRAINT draft_sequences_pkey PRIMARY KEY (id);


--
-- Name: drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY drafts
    ADD CONSTRAINT drafts_pkey PRIMARY KEY (id);


--
-- Name: email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: email_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY email_tokens
    ADD CONSTRAINT email_tokens_pkey PRIMARY KEY (id);


--
-- Name: facebook_user_infos_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY facebook_user_infos
    ADD CONSTRAINT facebook_user_infos_pkey PRIMARY KEY (id);


--
-- Name: forum_thread_link_clicks_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topic_link_clicks
    ADD CONSTRAINT forum_thread_link_clicks_pkey PRIMARY KEY (id);


--
-- Name: forum_thread_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topic_links
    ADD CONSTRAINT forum_thread_links_pkey PRIMARY KEY (id);


--
-- Name: forum_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topics
    ADD CONSTRAINT forum_threads_pkey PRIMARY KEY (id);


--
-- Name: incoming_links_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY incoming_links
    ADD CONSTRAINT incoming_links_pkey PRIMARY KEY (id);


--
-- Name: invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY invites
    ADD CONSTRAINT invites_pkey PRIMARY KEY (id);


--
-- Name: message_bus_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY message_bus
    ADD CONSTRAINT message_bus_pkey PRIMARY KEY (id);


--
-- Name: notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: onebox_renders_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY onebox_renders
    ADD CONSTRAINT onebox_renders_pkey PRIMARY KEY (id);


--
-- Name: post_action_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY post_action_types
    ADD CONSTRAINT post_action_types_pkey PRIMARY KEY (id);


--
-- Name: post_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY post_actions
    ADD CONSTRAINT post_actions_pkey PRIMARY KEY (id);


--
-- Name: posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: site_customizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY site_customizations
    ADD CONSTRAINT site_customizations_pkey PRIMARY KEY (id);


--
-- Name: site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: topic_allowed_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topic_allowed_users
    ADD CONSTRAINT topic_allowed_users_pkey PRIMARY KEY (id);


--
-- Name: topic_invites_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY topic_invites
    ADD CONSTRAINT topic_invites_pkey PRIMARY KEY (id);


--
-- Name: trust_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY trust_levels
    ADD CONSTRAINT trust_levels_pkey PRIMARY KEY (id);


--
-- Name: twitter_user_infos_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY twitter_user_infos
    ADD CONSTRAINT twitter_user_infos_pkey PRIMARY KEY (id);


--
-- Name: uploads_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY uploads
    ADD CONSTRAINT uploads_pkey PRIMARY KEY (id);


--
-- Name: user_open_ids_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_open_ids
    ADD CONSTRAINT user_open_ids_pkey PRIMARY KEY (id);


--
-- Name: user_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY user_visits
    ADD CONSTRAINT user_visits_pkey PRIMARY KEY (id);


--
-- Name: users_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -; Tablespace: 
--

ALTER TABLE ONLY versions
    ADD CONSTRAINT versions_pkey PRIMARY KEY (id);


--
-- Name: cat_featured_threads; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX cat_featured_threads ON category_featured_topics USING btree (category_id, topic_id);


--
-- Name: idx_search_thread; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_search_thread ON topics USING gin (to_tsvector('english'::regconfig, (title)::text));


--
-- Name: idx_search_user; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX idx_search_user ON users USING gin (to_tsvector('english'::regconfig, (username)::text));


--
-- Name: idx_unique_actions; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX idx_unique_actions ON post_actions USING btree (user_id, post_action_type_id, post_id) WHERE (deleted_at IS NULL);


--
-- Name: idx_unique_rows; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX idx_unique_rows ON user_actions USING btree (action_type, user_id, target_topic_id, target_post_id, acting_user_id);


--
-- Name: incoming_index; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX incoming_index ON incoming_links USING btree (topic_id, post_number);


--
-- Name: index_actions_on_acting_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_actions_on_acting_user_id ON user_actions USING btree (acting_user_id);


--
-- Name: index_actions_on_user_id_and_action_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_actions_on_user_id_and_action_type ON user_actions USING btree (user_id, action_type);


--
-- Name: index_categories_on_forum_thread_count; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_categories_on_forum_thread_count ON categories USING btree (topic_count);


--
-- Name: index_categories_on_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_categories_on_name ON categories USING btree (name);


--
-- Name: index_category_featured_users_on_category_id_and_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_category_featured_users_on_category_id_and_user_id ON category_featured_users USING btree (category_id, user_id);


--
-- Name: index_draft_sequences_on_user_id_and_draft_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_draft_sequences_on_user_id_and_draft_key ON draft_sequences USING btree (user_id, draft_key);


--
-- Name: index_drafts_on_user_id_and_draft_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_drafts_on_user_id_and_draft_key ON drafts USING btree (user_id, draft_key);


--
-- Name: index_email_logs_on_created_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_email_logs_on_created_at ON email_logs USING btree (created_at DESC);


--
-- Name: index_email_logs_on_user_id_and_created_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_email_logs_on_user_id_and_created_at ON email_logs USING btree (user_id, created_at DESC);


--
-- Name: index_email_tokens_on_token; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_email_tokens_on_token ON email_tokens USING btree (token);


--
-- Name: index_facebook_user_infos_on_facebook_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_facebook_user_infos_on_facebook_user_id ON facebook_user_infos USING btree (facebook_user_id);


--
-- Name: index_facebook_user_infos_on_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_facebook_user_infos_on_user_id ON facebook_user_infos USING btree (user_id);


--
-- Name: index_forum_thread_link_clicks_on_forum_thread_link_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_forum_thread_link_clicks_on_forum_thread_link_id ON topic_link_clicks USING btree (topic_link_id);


--
-- Name: index_forum_thread_links_on_forum_thread_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_forum_thread_links_on_forum_thread_id ON topic_links USING btree (topic_id);


--
-- Name: index_forum_thread_links_on_forum_thread_id_and_post_id_and_url; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_forum_thread_links_on_forum_thread_id_and_post_id_and_url ON topic_links USING btree (topic_id, post_id, url);


--
-- Name: index_forum_thread_users_on_forum_thread_id_and_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_forum_thread_users_on_forum_thread_id_and_user_id ON topic_users USING btree (topic_id, user_id);


--
-- Name: index_forum_threads_on_bumped_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_forum_threads_on_bumped_at ON topics USING btree (bumped_at DESC);


--
-- Name: index_forum_threads_on_category_id_and_sub_tag_and_bumped_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_forum_threads_on_category_id_and_sub_tag_and_bumped_at ON topics USING btree (category_id, sub_tag, bumped_at);


--
-- Name: index_invites_on_email_and_invited_by_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_invites_on_email_and_invited_by_id ON invites USING btree (email, invited_by_id);


--
-- Name: index_invites_on_invite_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_invites_on_invite_key ON invites USING btree (invite_key);


--
-- Name: index_message_bus_on_created_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_message_bus_on_created_at ON message_bus USING btree (created_at);


--
-- Name: index_notifications_on_post_action_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_notifications_on_post_action_id ON notifications USING btree (post_action_id);


--
-- Name: index_notifications_on_user_id_and_created_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_notifications_on_user_id_and_created_at ON notifications USING btree (user_id, created_at);


--
-- Name: index_onebox_renders_on_url; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_onebox_renders_on_url ON onebox_renders USING btree (url);


--
-- Name: index_post_actions_on_post_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_post_actions_on_post_id ON post_actions USING btree (post_id);


--
-- Name: index_post_onebox_renders_on_post_id_and_onebox_render_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_post_onebox_renders_on_post_id_and_onebox_render_id ON post_onebox_renders USING btree (post_id, onebox_render_id);


--
-- Name: index_post_replies_on_post_id_and_reply_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_post_replies_on_post_id_and_reply_id ON post_replies USING btree (post_id, reply_id);


--
-- Name: index_posts_on_reply_to_post_number; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_posts_on_reply_to_post_number ON posts USING btree (reply_to_post_number);


--
-- Name: index_posts_on_topic_id_and_post_number; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_posts_on_topic_id_and_post_number ON posts USING btree (topic_id, post_number);


--
-- Name: index_site_customizations_on_key; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_site_customizations_on_key ON site_customizations USING btree (key);


--
-- Name: index_topic_allowed_users_on_topic_id_and_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_topic_allowed_users_on_topic_id_and_user_id ON topic_allowed_users USING btree (topic_id, user_id);


--
-- Name: index_topic_allowed_users_on_user_id_and_topic_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_topic_allowed_users_on_user_id_and_topic_id ON topic_allowed_users USING btree (user_id, topic_id);


--
-- Name: index_topic_invites_on_invite_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_topic_invites_on_invite_id ON topic_invites USING btree (invite_id);


--
-- Name: index_topic_invites_on_topic_id_and_invite_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_topic_invites_on_topic_id_and_invite_id ON topic_invites USING btree (topic_id, invite_id);


--
-- Name: index_twitter_user_infos_on_twitter_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_twitter_user_infos_on_twitter_user_id ON twitter_user_infos USING btree (twitter_user_id);


--
-- Name: index_twitter_user_infos_on_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_twitter_user_infos_on_user_id ON twitter_user_infos USING btree (user_id);


--
-- Name: index_uploads_on_forum_thread_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_uploads_on_forum_thread_id ON uploads USING btree (topic_id);


--
-- Name: index_uploads_on_user_id; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_uploads_on_user_id ON uploads USING btree (user_id);


--
-- Name: index_user_open_ids_on_url; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_user_open_ids_on_url ON user_open_ids USING btree (url);


--
-- Name: index_user_visits_on_user_id_and_visited_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_user_visits_on_user_id_and_visited_at ON user_visits USING btree (user_id, visited_at);


--
-- Name: index_users_on_auth_token; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_users_on_auth_token ON users USING btree (auth_token);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_email ON users USING btree (email);


--
-- Name: index_users_on_last_posted_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_users_on_last_posted_at ON users USING btree (last_posted_at);


--
-- Name: index_users_on_username; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_username ON users USING btree (username);


--
-- Name: index_users_on_username_lower; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX index_users_on_username_lower ON users USING btree (username_lower);


--
-- Name: index_versions_on_created_at; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_versions_on_created_at ON versions USING btree (created_at);


--
-- Name: index_versions_on_number; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_versions_on_number ON versions USING btree (number);


--
-- Name: index_versions_on_tag; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_versions_on_tag ON versions USING btree (tag);


--
-- Name: index_versions_on_user_id_and_user_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_versions_on_user_id_and_user_type ON versions USING btree (user_id, user_type);


--
-- Name: index_versions_on_user_name; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_versions_on_user_name ON versions USING btree (user_name);


--
-- Name: index_versions_on_versioned_id_and_versioned_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_versions_on_versioned_id_and_versioned_type ON versions USING btree (versioned_id, versioned_type);


--
-- Name: index_views_on_parent_id_and_parent_type; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX index_views_on_parent_id_and_parent_type ON views USING btree (parent_id, parent_type);


--
-- Name: post_timings_summary; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE INDEX post_timings_summary ON post_timings USING btree (topic_id, post_number);


--
-- Name: post_timings_unique; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX post_timings_unique ON post_timings USING btree (topic_id, post_number, user_id);


--
-- Name: unique_schema_migrations; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX unique_schema_migrations ON schema_migrations USING btree (version);


--
-- Name: unique_views; Type: INDEX; Schema: public; Owner: -; Tablespace: 
--

CREATE UNIQUE INDEX unique_views ON views USING btree (parent_id, parent_type, ip, viewed_at);


--
-- PostgreSQL database dump complete
--

