// I am a web worker
// not transpiled
