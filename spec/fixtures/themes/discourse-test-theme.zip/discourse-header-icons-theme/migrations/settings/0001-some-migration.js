export default function migrate(settings) {
  return settings;
}
