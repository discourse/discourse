# Stock vips production-path benchmark

| Operation | Method | p50 time | Maximum peak RSS | Time difference vs IM | Memory difference vs IM |
| --- | --- | ---: | ---: | ---: | ---: |
| Optimized resize (photograph) | ImageMagick | 263.58 ms | 727.67 MiB | — | — |
| Optimized resize (photograph) | VIPS-enabled production path | 146.64 ms | 681.50 MiB | -116.94 ms (-44.4%) | -46.17 MiB (-6.3%) |
| Optimized north crop (high detail) | ImageMagick | 794.61 ms | 450.71 MiB | — | — |
| Optimized north crop (high detail) | VIPS-enabled production path | 850.54 ms | 724.41 MiB | +55.92 ms (+7.0%) | +273.70 MiB (+60.7%) |
| Optimized downsize (8900×8900) | ImageMagick | 953.86 ms | 1477.15 MiB | — | — |
| Optimized downsize (8900×8900) | VIPS-enabled production path | 492.88 ms | 426.34 MiB | -460.98 ms (-48.3%) | -1050.80 MiB (-71.1%) |
| PNG-to-JPEG conversion | ImageMagick | 199.03 ms | 686.93 MiB | — | — |
| PNG-to-JPEG conversion | VIPS-enabled production path | 44.37 ms | 727.76 MiB | -154.67 ms (-77.7%) | +40.83 MiB (+5.9%) |
| JPEG recompression | ImageMagick | 194.60 ms | 448.19 MiB | — | — |
| JPEG recompression | VIPS-enabled production path | 38.44 ms | 727.78 MiB | -156.15 ms (-80.2%) | +279.59 MiB (+62.4%) |
| HEIC-to-JPEG conversion | ImageMagick | 54.67 ms | 727.70 MiB | — | — |
| HEIC-to-JPEG conversion | VIPS-enabled production path | 43.05 ms | 396.38 MiB | -11.62 ms (-21.3%) | -331.32 MiB (-45.5%) |
| EXIF orientation correction | ImageMagick | 61.98 ms | 727.83 MiB | — | — |
| EXIF orientation correction | VIPS-enabled production path | 39.21 ms | 727.81 MiB | -22.78 ms (-36.7%) | -0.02 MiB (-0.0%) |
| SVG dimension probe | ImageMagick | 120.22 ms | 375.59 MiB | — | — |
| SVG dimension probe | VIPS-enabled production path | 126.59 ms | 720.98 MiB | +6.38 ms (+5.3%) | +345.39 MiB (+92.0%) |
| Animated WebP fallback probe | ImageMagick | 116.14 ms | 690.62 MiB | — | — |
| Animated WebP fallback probe | VIPS-enabled production path | 113.40 ms | 724.61 MiB | -2.74 ms (-2.4%) | +33.98 MiB (+4.9%) |
| JPEG target-quality decision | ImageMagick | 111.30 ms | 379.65 MiB | — | — |
| JPEG target-quality decision | VIPS-enabled production path | 0.43 ms | 345.21 MiB | -110.88 ms (-99.6%) | -34.44 MiB (-9.1%) |
| ICO-to-PNG conversion | ImageMagick | 13.60 ms | 690.63 MiB | — | — |
| ICO-to-PNG conversion | VIPS-enabled production path | 3.78 ms | 372.95 MiB | -9.81 ms (-72.2%) | -317.68 MiB (-46.0%) |

Times use only the dedicated timing samples. RSS is the maximum observed process-tree peak across the dedicated RSS samples; it is not a mean of per-run peaks. Both engines use their defaults and `VIPS_CONCURRENCY` is absent.

The no-operation fork baseline was 290.01 MiB p50 and 290.04 MiB maximum. Small RSS differences near that baseline should not be attributed to an image engine.

Every recorded sample passed the operation-specific semantic and visual comparison against the preserved ImageMagick reference output.

## Material time regressions

None met the investigation threshold of both 5 ms and 10% slower than ImageMagick.

The raw samples, exact environment, source and fixture hashes, correctness outputs, and machine-readable analysis are stored beside this summary.
